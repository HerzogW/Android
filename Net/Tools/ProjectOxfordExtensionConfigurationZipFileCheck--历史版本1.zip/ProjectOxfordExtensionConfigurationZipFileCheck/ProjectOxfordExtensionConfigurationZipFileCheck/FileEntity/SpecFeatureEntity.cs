﻿namespace ProjectOxfordExtensionConfigurationZipFileCheck
{
    /// <summary>
    /// 
    /// </summary>
    public class SpecFeatureEntity
    {
        public string id { get; set; }

        public string displayName { get; set; }

        public string iconSvgData { get; set; }

        public string iconName { get; set; }
    }
}
