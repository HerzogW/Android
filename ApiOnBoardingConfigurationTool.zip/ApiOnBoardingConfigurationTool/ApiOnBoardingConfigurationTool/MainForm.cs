﻿

namespace ApiOnBoardingConfigurationTool
{
    using Microsoft.Azure;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;

    /// <summary>
    /// The MainForm
    /// </summary>
    /// <seealso cref="System.Windows.Forms.Form" />
    public partial class MainForm : Form
    {

        /// <summary>
        /// The API on boarding configuration tool temporary folder
        /// </summary>
        private const string ApiOnBoardingConfigurationToolFolder = @"C:\ApiOnBoardingConfigurationToolTemp\";

        private const string ApiOnBoardingConfigurationToolSaveToLocalFolder = @"C:\ApiOnBoardingConfigurationToolTemp\SaveToLocal\";

        private const string ApiOnBoardingConfigurationToolInnerTempFolder = @"C:\ApiOnBoardingConfigurationToolTemp\Temp\";

        private const string LoadingFileMessage = "Loading files...";

        private const string OccurErrorMessage = "Occured some errors!";

        private const string LoadedSuccessfullyMessage = "Loaded successfully!";

        /// <summary>
        /// The resource token
        /// </summary>
        private const string ResourceToken = "ms-resource:";

        /// <summary>
        /// The icons token
        /// </summary>
        private const string IconToken = "ms-icon:";

        /// <summary>
        /// The API configuration storage container
        /// </summary>
        public string ApiConfigurationStorageContainerName = "apiconfiguration";

        /// <summary>
        /// The alert title
        /// </summary>
        private const string AlertTitle = "Alert";

        /// <summary>
        /// The exception title
        /// </summary>
        private const string ExceptionTitle = "Exception";

        private const string CommonAlertText1 = "Occured some errors!\r\nPlease check the last ErrorLog";

        /// <summary>
        /// The setting format
        /// </summary>
        private JsonSerializerSettings settingFormat = new JsonSerializerSettings()
        {
            Formatting = Formatting.Indented,
            NullValueHandling = NullValueHandling.Include,
            MissingMemberHandling = MissingMemberHandling.Error
        };

        /// <summary>
        /// The special setting format
        /// </summary>
        private JsonSerializerSettings specialSettingFormat = new JsonSerializerSettings()
        {
            Formatting = Formatting.Indented,
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };

        private Dictionary<string, string> ApiConfigIcons;
        //private ApiConfigurationData cacheConfigurationData;

        /// <summary>
        /// The list cached API configuration data
        /// </summary>
        private List<ApiConfigurationData> ListCachedApiConfigurationData;

        /// <summary>
        /// Initializes a new instance of the <see cref="MainForm"/> class.
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
            string containerName = CloudConfigurationManager.GetSetting("ApiConfigurationStorageContainerName");
            if (!string.IsNullOrWhiteSpace(containerName))
            {
                this.ApiConfigurationStorageContainerName = containerName;
            }
        }

        #region Extension Configuration

        /// <summary>
        /// Handles the Click event of the ECBtnCreate control.
        /// Create a new Extension Configuration Folder or Zip file.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void ECBtnCreate_Click(object sender, EventArgs e)
        {
            ResetAllExtensionConfigurationControls();
        }

        /// <summary>
        /// Handles the Click event of the ECBtnLoadFromLocal control.
        /// Load Configuration Folder from Local.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void ECBtnLoadFromLocal_Click(object sender, EventArgs e)
        {
            ApiConfigurationManager manager = new ApiConfigurationManager();
            ApiConfigurationData cacheConfigurationData;

            if (this.ECFolderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                string folderName = this.ECFolderBrowserDialog.SelectedPath.Substring(this.ECFolderBrowserDialog.SelectedPath.LastIndexOf(@"\") + 1);

                string tempZipFilepath = ApiConfigurationManager.CompressFolderContentIntoStream(this.ECFolderBrowserDialog.SelectedPath, ApiOnBoardingConfigurationToolInnerTempFolder);
                FileInfo fileInfo = new FileInfo(tempZipFilepath);
                using (Stream stream = fileInfo.OpenRead())
                {
                    cacheConfigurationData = manager.VeriliadteStream(stream, folderName);
                }

                if (manager.listError.Count > 0)
                {
                    int i = 1;
                    string tempErrorMessage = DateTime.UtcNow.ToString() + "\r\n";
                    foreach (ErrorEntity errorEntity in manager.listError)
                    {
                        tempErrorMessage += (i++) + "、" + errorEntity.GetErrorInfo() + "\r\n";
                    }

                    LogError(tempErrorMessage);
                    MessageBox.Show(CommonAlertText1, AlertTitle);
                    this.ECTextActionMessage.Text = OccurErrorMessage;
                }

                if (cacheConfigurationData != null)
                {
                    cacheConfigurationData.ApiFolderName = folderName;
                    LoadApiConfigInfoToPage(cacheConfigurationData);
                }
            }
        }

        /// <summary>
        /// Handles the Click event of the ECBtnLoadFromPPEBlob control.
        /// Load Configuration Zip files from PPE Blob.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void ECBtnLoadFromPPEBlob_Click(object sender, EventArgs e)
        {
            this.ECBtnCreate.Enabled = false;
            this.ECBtnLoadFromPPEBlob.Enabled = false;
            this.ECBtnLoadFromLocal.Enabled = false;
            this.ECTextActionMessage.Text = LoadingFileMessage;

            var apiConfigurationPublicAccessUrl = CloudConfigurationManager.GetSetting("ApiConfigurationPublicAccessUrl");

            ApiConfigurationManager manager = new ApiConfigurationManager(apiConfigurationPublicAccessUrl, this.ApiConfigurationStorageContainerName);
            ListCachedApiConfigurationData = manager.LoadDataToCache();

            List<ErrorEntity> listError = manager.listError;

            if (manager.listError.Count > 0)
            {
                this.ECTextActionMessage.Text = OccurErrorMessage;
                int i = 1;
                string tempErrorMessage = DateTime.UtcNow.ToString() + "\r\n";
                foreach (ErrorEntity errorMessage in manager.listError)
                {
                    tempErrorMessage += (i++) + "、" + errorMessage.GetErrorInfo() + "\r\n";
                }

                LogError(tempErrorMessage);
                MessageBox.Show(CommonAlertText1, AlertTitle);
                this.ECTextActionMessage.Text = OccurErrorMessage;
            }
            else
            {
                this.ECTextActionMessage.Text = LoadedSuccessfullyMessage;
            }

            LoadApiItemList();

            this.ECBtnCreate.Enabled = true;
            this.ECBtnLoadFromPPEBlob.Enabled = true;
            this.ECBtnLoadFromLocal.Enabled = true;
        }

        /// <summary>
        /// Handles the DoubleClick event of the ECListItems control.
        /// Api configuration packages list.(Double click to load on the pages.)
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void ECListItems_DoubleClick(object sender, EventArgs e)
        {
            string selectedApiItemName = this.ECListItems.SelectedItem.ToString();
            foreach (var apiConfigInfo in ListCachedApiConfigurationData)
            {
                if (apiConfigInfo.ApiFolderName.Equals(selectedApiItemName))
                {
                    LoadApiConfigInfoToPage(apiConfigInfo);
                    break;
                }
            }
        }

        #region Flags Operation
        /// <summary>
        /// Handles the Click event of the ECBtnIconsFlag control.
        /// The Flag for Icons.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
        private void ECBtnIconsFlag_Click(object sender, EventArgs e)
        {
            this.TabApiItemPage.SelectedTab = this.TabIcon;
        }

        /// <summary>
        /// Handles the Click event of the ECBtnApiFlag control.
        /// The flag for Api.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
        private void ECBtnApiFlag_Click(object sender, EventArgs e)
        {
            this.TabApiItemPage.SelectedTab = this.TabApi;
        }

        /// <summary>
        /// Handles the Click event of the ECBtnQuickStartsFlag control.
        /// The falg for QuickStarts
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
        private void ECBtnQuickStartsFlag_Click(object sender, EventArgs e)
        {
            this.TabApiItemPage.SelectedTab = this.TabQuickStarts;
        }

        /// <summary>
        /// Handles the Click event of the ECBtnSpecFlag control.
        /// The flag for Spec.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
        private void ECBtnSpecFlag_Click(object sender, EventArgs e)
        {
            this.TabApiItemPage.SelectedTab = this.TabSpec;
        }
        #endregion

        #region Reset Pages
        private void ResetAllFlagControl()
        {
            ///Flags
            this.ECBtnIconsFlag.BackColor = System.Drawing.Color.Orange;
            this.ECBtnApiFlag.BackColor = System.Drawing.Color.Orange;
            this.ECBtnQuickStartsFlag.BackColor = System.Drawing.Color.Orange;
            this.ECBtnSpecFlag.BackColor = System.Drawing.Color.Orange;
        }

        private void ResetIconsPage()
        {
            ///Svg Files
            this.ECTextIconFolderPath.Text = string.Empty;
            this.ECTextSvgFiles.Text = string.Empty;
            this.ECTextSvgFiles.BackColor = System.Drawing.Color.White;
        }

        private void ResetApiPage()
        {
            ///Api.Json
            this.ECTextApiItem.Text = string.Empty;
            this.ECTextApiItem.BackColor = System.Drawing.Color.White;
            this.ECTextApiTitle.Text = string.Empty;
            this.ECTextApiTitle.BackColor = System.Drawing.Color.White;
            this.ECTextApiSubTitle.Text = string.Empty;
            this.ECTextApiSubTitle.BackColor = System.Drawing.Color.White;
            this.ECCBApiIconData.SelectedItem = string.Empty;
            this.ECCBApiIconData.BackColor = System.Drawing.Color.White;
            this.ECTextApiCategory.Text = string.Empty;
            //this.ECTextApiCategory.BackColor = System.Drawing.Color.White;
            this.ECTextApiCategories.Text = "\"CognitiveServices\"";
            this.ECTextApiCategories.BackColor = System.Drawing.Color.White;
            this.ECTextApiSkuQuotaCode.Text = string.Empty;
            this.ECTextApiSkuQuotaName.Text = string.Empty;
            this.ECTextApiSkuQuotaQuota.Text = string.Empty;
            this.ECTextApiSkuQuotaData.Text = string.Empty;
            this.ECRDBApiShowLegalTermTrue.Checked = true;
            this.ECRDBApiShowLegalTermFalse.Checked = false;
            this.ECTextApiDefaultLegalTerm.Text = string.Empty;
        }

        private void ResetQuickStartsPage()
        {
            ///QuickStarts.Json
            this.ECTextQuickStartItemTitle.Text = string.Empty;
            this.ECCBQuickStartItemIcon.SelectedItem = string.Empty;
            this.ECTextQuickStartItemDescription.Text = string.Empty;
            this.ECTextQuickStartItemLinkTitle.Text = string.Empty;
            this.ECTextQuickStartItemLinkUri.Text = string.Empty;
            this.ECTextQuickStartItemLinks.Text = string.Empty;
            this.ECTextQuickStartItems.Text = string.Empty;
            this.ECTextQuickStartItems.BackColor = System.Drawing.Color.White;
        }

        private void ResetSpecFeaturesPage()
        {
            ///Spec.Json Features
            this.ECTextSpecFeatureItemDisplayName.Text = string.Empty;
            this.ECCBSpecFeatureItemIconSvgData.SelectedItem = string.Empty;
            this.ECTextSpecFeatureItemIconName.Text = string.Empty;
            this.ECTextSpecFeatureItems.Text = string.Empty;
            this.ECTextSpecFeatureItems.BackColor = System.Drawing.Color.White;
        }

        private void ResetSpecItemsPage()
        {
            ///Spec.Json SpecItems
            this.ECTextSpecItemSpecCode.Text = string.Empty;
            this.ECCBSpecItemColorScheme.SelectedItem = string.Empty;
            this.ECTextSpecItemTitle.Text = string.Empty;
            this.ECTextSpecItemPromotedFeatureItemValue.Text = string.Empty;
            this.ECTextSpecItemPromotedFeatureItemUnitDescription.Text = string.Empty;
            this.ECTextSpecItemPromotedFeatureItems.Text = string.Empty;
            this.ECCBSpecItemFeatureID.SelectedItem = string.Empty;
            this.ECTextSpecItemFeatureIDs.Text = string.Empty;
            this.ECTextSpecItemCostAmount.Text = string.Empty;
            this.ECTextSpecItemCostCurrencyCode.Text = string.Empty;
            this.ECTextSpecItemCostCaption.Text = string.Empty;
            this.ECTextSpecItems.Text = string.Empty;
            this.ECTextSpecItems.BackColor = System.Drawing.Color.White;
        }

        private void ResetSpecCostItemPage()
        {
            ///Spec.Json Cost Item
            this.ECCBSpecDefaultItemSpecCode.SelectedItem = string.Empty;
            this.ECTextSpecDefaultItemFirstPartyResourceID.Text = string.Empty;
            this.ECTextSpecDefaultItemFirstPartyQuantity.Text = string.Empty;
            this.ECTextSpecDefaultItemFirstPartyItems.Text = string.Empty;
            this.ECTextSpecDefaultItems.Text = string.Empty;
            this.ECTextSpecDefaultItems.BackColor = System.Drawing.Color.White;
        }

        private void ResetSpecAllowZeroCostPage()
        {
            ///Spec.Json AllowZeroCost
            this.ECCBSpecAllowZeroCostSpecCode.SelectedItem = string.Empty;
            this.ECTextSpecAllowZeroCostSpecCodeItems.Text = string.Empty;
            this.ECTextSpecAllowZeroCostSpecCodeItems.BackColor = System.Drawing.Color.White;
        }

        public void ResetOverAllPage()
        {
            ///OverAll
            this.ECTextOverAllApiJson.Text = string.Empty;
            this.ECTextOverAllQuickStartsJson.Text = string.Empty;
            this.ECTextOverAllSpecJson.Text = string.Empty;
            this.ECTextOverAllResourceENJson.Text = string.Empty;
            this.ECTextOverAllSvgIcons.Text = string.Empty;
        }

        /// <summary>
        /// Resets all extension configuration controls.
        /// </summary>
        private void ResetAllExtensionConfigurationControls()
        {
            ///ApiItemList
            this.ECListItems.Items.Clear();

            ResetAllFlagControl();
            ResetIconsPage();
            ResetApiPage();
            ResetQuickStartsPage();

            ResetSpecFeaturesPage();
            ResetSpecItemsPage();
            ResetSpecCostItemPage();
            ResetSpecAllowZeroCostPage();
            ResetOverAllPage();

            this.ECTextActionMessage.Text = "Reseted All!";
        }

        #endregion

        /// <summary>
        /// Loads the API item list.
        /// </summary>
        private void LoadApiItemList()
        {
            this.ECListItems.Items.Clear();

            foreach (var item in ListCachedApiConfigurationData)
            {
                this.ECListItems.Items.Add(item.ApiFolderName);
            }
        }

        private void LoadApiConfigInfoToPage(ApiConfigurationData apiConfigInfo)
        {
            if (apiConfigInfo.Icons.Count > 0)
            {
                foreach (var icon in apiConfigInfo.Icons)
                {
                    this.ECTextSvgFiles.Text += icon.Key + "\r\n";
                }

                this.ApiConfigIcons = apiConfigInfo.Icons;
            }
            else
            {
                this.ECTextSvgFiles.BackColor = System.Drawing.Color.Red;
                this.ECBtnIconsFlag.BackColor = System.Drawing.Color.Red;
            }

            Dictionary<string, string> resourceEN;
            if (apiConfigInfo.Resources.ContainsKey("en"))
            {
                resourceEN = apiConfigInfo.Resources["en"];
            }
            else
            {
                resourceEN = new Dictionary<string, string>();
            }

            ApiEntity apiEntity = JsonConvert.DeserializeObject<ApiEntity>(apiConfigInfo.ApiItem.ToString());
            if (apiEntity != null)
            {
                SetControlContentText(this.ECTextApiItem, apiEntity.item, this.ECBtnApiFlag);
                SetControlContentText(this.ECTextApiTitle, resourceEN[apiEntity.title.Replace(ResourceToken, string.Empty)], this.ECBtnApiFlag);
                SetControlContentText(this.ECTextApiSubTitle, resourceEN[apiEntity.subtitle.Replace(ResourceToken, string.Empty)], this.ECBtnApiFlag);
                if (this.ApiConfigIcons.ContainsKey(apiEntity.iconData.Replace(IconToken, string.Empty)))
                {
                    SetControlContentText(this.ECCBApiIconData, apiEntity.iconData.Replace(IconToken, string.Empty), this.ECBtnApiFlag);
                }
                else
                {
                    SetControlContentText(this.ECCBApiIconData, null, this.ECBtnApiFlag);
                }


                SetControlContentText(this.ECTextApiCategories, JsonConvert.SerializeObject(apiEntity.categories, settingFormat), this.ECBtnApiFlag);
                if (apiEntity.skuQuota.Count > 0)
                {
                    SetControlContentText(this.ECTextApiSkuQuotaData, JsonConvert.SerializeObject(apiEntity.skuQuota, settingFormat), this.ECBtnApiFlag, false);
                }

                this.ECRDBApiShowLegalTermTrue.Checked = apiEntity.showLegalTerm;
                this.ECRDBApiShowLegalTermFalse.Checked = !apiEntity.showLegalTerm;

                SetControlContentText(this.ECTextApiDefaultLegalTerm, apiEntity.defaultLegalTerm, this.ECBtnApiFlag, false);
            }
            else
            {
                this.ECBtnApiFlag.BackColor = System.Drawing.Color.DarkRed;
            }

            QuickStartsEntity quickStartsEntity = JsonConvert.DeserializeObject<QuickStartsEntity>(apiConfigInfo.QuickStart.ToString());
            if (quickStartsEntity != null)
            {
                SetControlContentText(this.ECTextQuickStartItems, JsonConvert.SerializeObject(quickStartsEntity.quickStarts, settingFormat), this.ECBtnApiFlag);
            }
            else
            {
                this.ECBtnQuickStartsFlag.BackColor = System.Drawing.Color.DarkRed;
            }

            SpecsEntity specEntity = JsonConvert.DeserializeObject<SpecsEntity>(apiConfigInfo.Spec.ToString());
            if (specEntity != null)
            {
                SetControlContentText(this.ECTextSpecFeatureItems, JsonConvert.SerializeObject(specEntity.features, settingFormat), this.ECBtnSpecFlag);
                SetControlContentText(this.ECTextSpecItems, JsonConvert.SerializeObject(specEntity.specs, settingFormat), this.ECBtnSpecFlag);
                SetControlContentText(this.ECTextSpecDefaultItems, JsonConvert.SerializeObject(specEntity.resourceMap.specResourceMapDefault, settingFormat), this.ECBtnSpecFlag);
                SetControlContentText(this.ECTextSpecAllowZeroCostSpecCodeItems, JsonConvert.SerializeObject(specEntity.specsToAllowZeroCost, settingFormat), this.ECBtnSpecFlag);
            }
            else
            {
                this.ECBtnSpecFlag.BackColor = System.Drawing.Color.DarkRed;
            }
        }

        #endregion

        private void SetControlContentText(Control control, string contentText, Control flagControl, bool isRequired = true)
        {
            if (isRequired)
            {
                if (string.IsNullOrWhiteSpace(contentText))
                {
                    control.BackColor = System.Drawing.Color.Red;
                    flagControl.BackColor = System.Drawing.Color.Red;
                }
                else
                {
                    control.BackColor = System.Drawing.Color.White;
                    control.Text = contentText;
                }
            }
            else
            {
                if (!string.IsNullOrWhiteSpace(contentText))
                {
                    control.Text = contentText;
                }
            }
        }

        /// <summary>
        /// Logs the error.
        /// </summary>
        /// <param name="content">The content.</param>
        private void LogError(string content)
        {
            try
            {
                string logFileName = string.Format("ErrorLog--{0}.txt", DateTime.Now.ToString("yyyy-MM-dd"));
                string logFilePath = string.Format("{0}{1}", ApiOnBoardingConfigurationToolFolder, logFileName);
                using (FileStream fs = File.Open(logFilePath, FileMode.OpenOrCreate))
                {
                    using (StreamWriter sw = new StreamWriter(fs))
                    {
                        sw.Write(content);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ExceptionTitle);
            }
        }
    }
}
