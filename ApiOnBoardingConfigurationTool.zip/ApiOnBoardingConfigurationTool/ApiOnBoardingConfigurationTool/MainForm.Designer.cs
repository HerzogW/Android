﻿namespace ApiOnBoardingConfigurationTool
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.ECBtnSpecFlag = new System.Windows.Forms.Button();
            this.ECBtnQuickStartsFlag = new System.Windows.Forms.Button();
            this.ECBtnApiFlag = new System.Windows.Forms.Button();
            this.ECBtnIconsFlag = new System.Windows.Forms.Button();
            this.TabApiItemPage = new System.Windows.Forms.TabControl();
            this.TabIcon = new System.Windows.Forms.TabPage();
            this.ECLabelIconFolderPath = new System.Windows.Forms.Label();
            this.ECTextIconFolderPath = new System.Windows.Forms.TextBox();
            this.ECBtnSelectSvgFolder = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ECTextSvgFiles = new System.Windows.Forms.TextBox();
            this.TabApi = new System.Windows.Forms.TabPage();
            this.ECBtnSaveApiInfo = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.ECTextApiDefaultLegalTerm = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ECRDBApiShowLegalTermTrue = new System.Windows.Forms.RadioButton();
            this.ECRDBApiShowLegalTermFalse = new System.Windows.Forms.RadioButton();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.BtnApiCategoryAdd = new System.Windows.Forms.Button();
            this.ECTextApiCategory = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ECTextApiCategories = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.BtnApiSkuQuotaAdd = new System.Windows.Forms.Button();
            this.ECTextApiSkuQuotaData = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.ECTextApiSkuQuotaCode = new System.Windows.Forms.TextBox();
            this.ECTextApiSkuQuotaQuota = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.ECTextApiSkuQuotaName = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.ECCBApiIconData = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.ECTextApiSubTitle = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ECTextApiTitle = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ECTextApiItem = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TabQuickStarts = new System.Windows.Forms.TabPage();
            this.ECBtnSaveQuickStartsInfo = new System.Windows.Forms.Button();
            this.ECBtnAddQuickStartItem = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.ECCBQuickStartItemIcon = new System.Windows.Forms.ComboBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.ECBtnAddLinkItem = new System.Windows.Forms.Button();
            this.ECTextQuickStartItemLinks = new System.Windows.Forms.TextBox();
            this.ECTextQuickStartItemLinkUri = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.ECTextQuickStartItemLinkTitle = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.ECTextQuickStartItemDescription = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.ECTextQuickStartItemTitle = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.ECTextQuickStartItems = new System.Windows.Forms.TextBox();
            this.TabSpec = new System.Windows.Forms.TabPage();
            this.ECBtnSaveSpecInfo = new System.Windows.Forms.Button();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.TabSpecFeatures = new System.Windows.Forms.TabPage();
            this.ECBtnAddSpecFeatureItem = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.ECTextSpecFeatureItems = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.ECCBSpecFeatureItemIconSvgData = new System.Windows.Forms.ComboBox();
            this.ECTextSpecFeatureItemIconName = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.ECTextSpecFeatureItemDisplayName = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.TabSpecItems = new System.Windows.Forms.TabPage();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.ECTextSpecItems = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.ECCBSpecItemColorScheme = new System.Windows.Forms.ComboBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.ECTextSpecItemCostCaption = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.ECTextSpecItemCostCurrencyCode = new System.Windows.Forms.TextBox();
            this.ECTextSpecItemCostAmount = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.ECTextSpecItemFeatureIDs = new System.Windows.Forms.TextBox();
            this.ECBtnAddFeatureID = new System.Windows.Forms.Button();
            this.ECCBSpecItemFeatureID = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.ECBtnAddPromotedFeature = new System.Windows.Forms.Button();
            this.ECTextSpecItemPromotedFeatureItemUnitDescription = new System.Windows.Forms.TextBox();
            this.ECTextSpecItemPromotedFeatureItemValue = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.ECTextSpecItemPromotedFeatureItems = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.ECTextSpecItemTitle = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.ECTextSpecItemSpecCode = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.TabSpecCostItems = new System.Windows.Forms.TabPage();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.ECTextSpecDefaultItems = new System.Windows.Forms.TextBox();
            this.ECBtnAddSpecDefaultItem = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.ECBtnAddSpecDefaultItemFirstPartyItem = new System.Windows.Forms.Button();
            this.ECTextSpecDefaultItemFirstPartyItems = new System.Windows.Forms.TextBox();
            this.ECTextSpecDefaultItemFirstPartyQuantity = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.ECTextSpecDefaultItemFirstPartyResourceID = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.ECCBSpecDefaultItemSpecCode = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.TabAllowZeroCost = new System.Windows.Forms.TabPage();
            this.ECTextSpecAllowZeroCostSpecCodeItems = new System.Windows.Forms.TextBox();
            this.ECBtnAddSpecAllowZeroCostSpecCodeItem = new System.Windows.Forms.Button();
            this.ECCBSpecAllowZeroCostSpecCode = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.TabOverAll = new System.Windows.Forms.TabPage();
            this.ECRDBSaveAsFolder = new System.Windows.Forms.RadioButton();
            this.ECRDBSaveAsZip = new System.Windows.Forms.RadioButton();
            this.ECBtnUploadToPPEBlob = new System.Windows.Forms.Button();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.ECTextOverAllSvgIcons = new System.Windows.Forms.TextBox();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.ECTextOverAllResourceENJson = new System.Windows.Forms.TextBox();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.ECTextOverAllSpecJson = new System.Windows.Forms.TextBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.ECTextOverAllQuickStartsJson = new System.Windows.Forms.TextBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.ECTextOverAllApiJson = new System.Windows.Forms.TextBox();
            this.ECBtnSaveToLocal = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ECTextActionMessage = new System.Windows.Forms.Label();
            this.ECListItems = new System.Windows.Forms.CheckedListBox();
            this.ECBtnLoadFromLocal = new System.Windows.Forms.Button();
            this.ECBtnLoadFromPPEBlob = new System.Windows.Forms.Button();
            this.ECBtnCreate = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ECTextStorageAccountKey = new System.Windows.Forms.TextBox();
            this.ECBtnUploadToProBlob = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ECTextStorageAccount = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.ECFolderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.TabApiItemPage.SuspendLayout();
            this.TabIcon.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.TabApi.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.TabQuickStarts.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.TabSpec.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.TabSpecFeatures.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.TabSpecItems.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.TabSpecCostItems.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.TabAllowZeroCost.SuspendLayout();
            this.TabOverAll.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(960, 703);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(952, 675);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Extension Configuration";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.groupBox27);
            this.panel1.Controls.Add(this.TabApiItemPage);
            this.panel1.Location = new System.Drawing.Point(176, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(770, 582);
            this.panel1.TabIndex = 2;
            // 
            // groupBox27
            // 
            this.groupBox27.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox27.Controls.Add(this.ECBtnSpecFlag);
            this.groupBox27.Controls.Add(this.ECBtnQuickStartsFlag);
            this.groupBox27.Controls.Add(this.ECBtnApiFlag);
            this.groupBox27.Controls.Add(this.ECBtnIconsFlag);
            this.groupBox27.Location = new System.Drawing.Point(3, 525);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(761, 54);
            this.groupBox27.TabIndex = 4;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "Flags";
            // 
            // ECBtnSpecFlag
            // 
            this.ECBtnSpecFlag.BackColor = System.Drawing.Color.Orange;
            this.ECBtnSpecFlag.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECBtnSpecFlag.Location = new System.Drawing.Point(573, 19);
            this.ECBtnSpecFlag.Name = "ECBtnSpecFlag";
            this.ECBtnSpecFlag.Size = new System.Drawing.Size(75, 23);
            this.ECBtnSpecFlag.TabIndex = 3;
            this.ECBtnSpecFlag.Text = "Spec";
            this.ECBtnSpecFlag.UseVisualStyleBackColor = false;
            this.ECBtnSpecFlag.Click += new System.EventHandler(this.ECBtnSpecFlag_Click);
            // 
            // ECBtnQuickStartsFlag
            // 
            this.ECBtnQuickStartsFlag.BackColor = System.Drawing.Color.Orange;
            this.ECBtnQuickStartsFlag.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECBtnQuickStartsFlag.Location = new System.Drawing.Point(411, 19);
            this.ECBtnQuickStartsFlag.Name = "ECBtnQuickStartsFlag";
            this.ECBtnQuickStartsFlag.Size = new System.Drawing.Size(75, 23);
            this.ECBtnQuickStartsFlag.TabIndex = 2;
            this.ECBtnQuickStartsFlag.Text = "QuickStarts";
            this.ECBtnQuickStartsFlag.UseVisualStyleBackColor = false;
            this.ECBtnQuickStartsFlag.Click += new System.EventHandler(this.ECBtnQuickStartsFlag_Click);
            // 
            // ECBtnApiFlag
            // 
            this.ECBtnApiFlag.BackColor = System.Drawing.Color.Orange;
            this.ECBtnApiFlag.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECBtnApiFlag.Location = new System.Drawing.Point(249, 19);
            this.ECBtnApiFlag.Name = "ECBtnApiFlag";
            this.ECBtnApiFlag.Size = new System.Drawing.Size(75, 23);
            this.ECBtnApiFlag.TabIndex = 1;
            this.ECBtnApiFlag.Text = "Api";
            this.ECBtnApiFlag.UseVisualStyleBackColor = false;
            this.ECBtnApiFlag.Click += new System.EventHandler(this.ECBtnApiFlag_Click);
            // 
            // ECBtnIconsFlag
            // 
            this.ECBtnIconsFlag.BackColor = System.Drawing.Color.Orange;
            this.ECBtnIconsFlag.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECBtnIconsFlag.Location = new System.Drawing.Point(87, 19);
            this.ECBtnIconsFlag.Name = "ECBtnIconsFlag";
            this.ECBtnIconsFlag.Size = new System.Drawing.Size(75, 23);
            this.ECBtnIconsFlag.TabIndex = 0;
            this.ECBtnIconsFlag.Text = "Icons";
            this.ECBtnIconsFlag.UseVisualStyleBackColor = false;
            this.ECBtnIconsFlag.Click += new System.EventHandler(this.ECBtnIconsFlag_Click);
            // 
            // TabApiItemPage
            // 
            this.TabApiItemPage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TabApiItemPage.Controls.Add(this.TabIcon);
            this.TabApiItemPage.Controls.Add(this.TabApi);
            this.TabApiItemPage.Controls.Add(this.TabQuickStarts);
            this.TabApiItemPage.Controls.Add(this.TabSpec);
            this.TabApiItemPage.Controls.Add(this.TabOverAll);
            this.TabApiItemPage.Location = new System.Drawing.Point(3, 3);
            this.TabApiItemPage.Name = "TabApiItemPage";
            this.TabApiItemPage.SelectedIndex = 0;
            this.TabApiItemPage.Size = new System.Drawing.Size(764, 517);
            this.TabApiItemPage.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.TabApiItemPage.TabIndex = 3;
            // 
            // TabIcon
            // 
            this.TabIcon.Controls.Add(this.ECLabelIconFolderPath);
            this.TabIcon.Controls.Add(this.ECTextIconFolderPath);
            this.TabIcon.Controls.Add(this.ECBtnSelectSvgFolder);
            this.TabIcon.Controls.Add(this.groupBox3);
            this.TabIcon.Location = new System.Drawing.Point(4, 22);
            this.TabIcon.Name = "TabIcon";
            this.TabIcon.Padding = new System.Windows.Forms.Padding(3);
            this.TabIcon.Size = new System.Drawing.Size(756, 491);
            this.TabIcon.TabIndex = 0;
            this.TabIcon.Text = "Icons";
            this.TabIcon.UseVisualStyleBackColor = true;
            // 
            // ECLabelIconFolderPath
            // 
            this.ECLabelIconFolderPath.AutoSize = true;
            this.ECLabelIconFolderPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECLabelIconFolderPath.Location = new System.Drawing.Point(9, 11);
            this.ECLabelIconFolderPath.Name = "ECLabelIconFolderPath";
            this.ECLabelIconFolderPath.Size = new System.Drawing.Size(64, 13);
            this.ECLabelIconFolderPath.TabIndex = 3;
            this.ECLabelIconFolderPath.Text = "Folder Path:";
            // 
            // ECTextIconFolderPath
            // 
            this.ECTextIconFolderPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextIconFolderPath.BackColor = System.Drawing.SystemColors.Control;
            this.ECTextIconFolderPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextIconFolderPath.Location = new System.Drawing.Point(93, 8);
            this.ECTextIconFolderPath.Name = "ECTextIconFolderPath";
            this.ECTextIconFolderPath.ReadOnly = true;
            this.ECTextIconFolderPath.Size = new System.Drawing.Size(574, 20);
            this.ECTextIconFolderPath.TabIndex = 2;
            // 
            // ECBtnSelectSvgFolder
            // 
            this.ECBtnSelectSvgFolder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ECBtnSelectSvgFolder.Location = new System.Drawing.Point(672, 6);
            this.ECBtnSelectSvgFolder.Name = "ECBtnSelectSvgFolder";
            this.ECBtnSelectSvgFolder.Size = new System.Drawing.Size(75, 23);
            this.ECBtnSelectSvgFolder.TabIndex = 1;
            this.ECBtnSelectSvgFolder.Text = "Select";
            this.ECBtnSelectSvgFolder.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.ECTextSvgFiles);
            this.groupBox3.Location = new System.Drawing.Point(6, 35);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(741, 450);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Svg Files";
            // 
            // ECTextSvgFiles
            // 
            this.ECTextSvgFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextSvgFiles.BackColor = System.Drawing.SystemColors.Control;
            this.ECTextSvgFiles.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSvgFiles.Location = new System.Drawing.Point(6, 19);
            this.ECTextSvgFiles.Multiline = true;
            this.ECTextSvgFiles.Name = "ECTextSvgFiles";
            this.ECTextSvgFiles.ReadOnly = true;
            this.ECTextSvgFiles.Size = new System.Drawing.Size(729, 424);
            this.ECTextSvgFiles.TabIndex = 0;
            // 
            // TabApi
            // 
            this.TabApi.Controls.Add(this.ECBtnSaveApiInfo);
            this.TabApi.Controls.Add(this.groupBox6);
            this.TabApi.Controls.Add(this.groupBox5);
            this.TabApi.Controls.Add(this.groupBox25);
            this.TabApi.Controls.Add(this.groupBox4);
            this.TabApi.Controls.Add(this.ECCBApiIconData);
            this.TabApi.Controls.Add(this.label7);
            this.TabApi.Controls.Add(this.ECTextApiSubTitle);
            this.TabApi.Controls.Add(this.label6);
            this.TabApi.Controls.Add(this.ECTextApiTitle);
            this.TabApi.Controls.Add(this.label5);
            this.TabApi.Controls.Add(this.ECTextApiItem);
            this.TabApi.Controls.Add(this.label3);
            this.TabApi.Location = new System.Drawing.Point(4, 22);
            this.TabApi.Name = "TabApi";
            this.TabApi.Padding = new System.Windows.Forms.Padding(3);
            this.TabApi.Size = new System.Drawing.Size(756, 491);
            this.TabApi.TabIndex = 1;
            this.TabApi.Text = "Api";
            this.TabApi.UseVisualStyleBackColor = true;
            // 
            // ECBtnSaveApiInfo
            // 
            this.ECBtnSaveApiInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ECBtnSaveApiInfo.Location = new System.Drawing.Point(625, 462);
            this.ECBtnSaveApiInfo.Name = "ECBtnSaveApiInfo";
            this.ECBtnSaveApiInfo.Size = new System.Drawing.Size(125, 23);
            this.ECBtnSaveApiInfo.TabIndex = 33;
            this.ECBtnSaveApiInfo.Text = "Save Api";
            this.ECBtnSaveApiInfo.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.Controls.Add(this.ECTextApiDefaultLegalTerm);
            this.groupBox6.Location = new System.Drawing.Point(6, 376);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(743, 80);
            this.groupBox6.TabIndex = 32;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Default Legal Term";
            // 
            // ECTextApiDefaultLegalTerm
            // 
            this.ECTextApiDefaultLegalTerm.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextApiDefaultLegalTerm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextApiDefaultLegalTerm.Location = new System.Drawing.Point(6, 19);
            this.ECTextApiDefaultLegalTerm.Multiline = true;
            this.ECTextApiDefaultLegalTerm.Name = "ECTextApiDefaultLegalTerm";
            this.ECTextApiDefaultLegalTerm.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextApiDefaultLegalTerm.Size = new System.Drawing.Size(731, 55);
            this.ECTextApiDefaultLegalTerm.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.ECRDBApiShowLegalTermTrue);
            this.groupBox5.Controls.Add(this.ECRDBApiShowLegalTermFalse);
            this.groupBox5.Location = new System.Drawing.Point(6, 319);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(745, 51);
            this.groupBox5.TabIndex = 31;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "ShowLegalTerm";
            // 
            // ECRDBApiShowLegalTermTrue
            // 
            this.ECRDBApiShowLegalTermTrue.AutoSize = true;
            this.ECRDBApiShowLegalTermTrue.Checked = true;
            this.ECRDBApiShowLegalTermTrue.Location = new System.Drawing.Point(227, 19);
            this.ECRDBApiShowLegalTermTrue.Name = "ECRDBApiShowLegalTermTrue";
            this.ECRDBApiShowLegalTermTrue.Size = new System.Drawing.Size(51, 17);
            this.ECRDBApiShowLegalTermTrue.TabIndex = 12;
            this.ECRDBApiShowLegalTermTrue.TabStop = true;
            this.ECRDBApiShowLegalTermTrue.Text = "True";
            this.ECRDBApiShowLegalTermTrue.UseVisualStyleBackColor = true;
            // 
            // ECRDBApiShowLegalTermFalse
            // 
            this.ECRDBApiShowLegalTermFalse.AutoSize = true;
            this.ECRDBApiShowLegalTermFalse.Location = new System.Drawing.Point(389, 19);
            this.ECRDBApiShowLegalTermFalse.Name = "ECRDBApiShowLegalTermFalse";
            this.ECRDBApiShowLegalTermFalse.Size = new System.Drawing.Size(55, 17);
            this.ECRDBApiShowLegalTermFalse.TabIndex = 13;
            this.ECRDBApiShowLegalTermFalse.Text = "False";
            this.ECRDBApiShowLegalTermFalse.UseVisualStyleBackColor = true;
            // 
            // groupBox25
            // 
            this.groupBox25.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox25.BackColor = System.Drawing.Color.Transparent;
            this.groupBox25.Controls.Add(this.BtnApiCategoryAdd);
            this.groupBox25.Controls.Add(this.ECTextApiCategory);
            this.groupBox25.Controls.Add(this.label8);
            this.groupBox25.Controls.Add(this.ECTextApiCategories);
            this.groupBox25.Location = new System.Drawing.Point(6, 85);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(744, 94);
            this.groupBox25.TabIndex = 30;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Categories";
            // 
            // BtnApiCategoryAdd
            // 
            this.BtnApiCategoryAdd.Location = new System.Drawing.Point(171, 62);
            this.BtnApiCategoryAdd.Name = "BtnApiCategoryAdd";
            this.BtnApiCategoryAdd.Size = new System.Drawing.Size(75, 23);
            this.BtnApiCategoryAdd.TabIndex = 8;
            this.BtnApiCategoryAdd.Text = "Add ▶";
            this.BtnApiCategoryAdd.UseVisualStyleBackColor = true;
            // 
            // ECTextApiCategory
            // 
            this.ECTextApiCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextApiCategory.Location = new System.Drawing.Point(20, 36);
            this.ECTextApiCategory.Name = "ECTextApiCategory";
            this.ECTextApiCategory.Size = new System.Drawing.Size(226, 20);
            this.ECTextApiCategory.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.label8.Location = new System.Drawing.Point(17, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Category:";
            // 
            // ECTextApiCategories
            // 
            this.ECTextApiCategories.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextApiCategories.BackColor = System.Drawing.SystemColors.Window;
            this.ECTextApiCategories.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.ECTextApiCategories.Location = new System.Drawing.Point(264, 19);
            this.ECTextApiCategories.Multiline = true;
            this.ECTextApiCategories.Name = "ECTextApiCategories";
            this.ECTextApiCategories.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextApiCategories.Size = new System.Drawing.Size(474, 66);
            this.ECTextApiCategories.TabIndex = 5;
            this.ECTextApiCategories.Text = "\"CognitiveServices\"";
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.BtnApiSkuQuotaAdd);
            this.groupBox4.Controls.Add(this.ECTextApiSkuQuotaData);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.ECTextApiSkuQuotaCode);
            this.groupBox4.Controls.Add(this.ECTextApiSkuQuotaQuota);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.ECTextApiSkuQuotaName);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Location = new System.Drawing.Point(6, 185);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(744, 128);
            this.groupBox4.TabIndex = 27;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "SkuQuota";
            // 
            // BtnApiSkuQuotaAdd
            // 
            this.BtnApiSkuQuotaAdd.Location = new System.Drawing.Point(171, 99);
            this.BtnApiSkuQuotaAdd.Name = "BtnApiSkuQuotaAdd";
            this.BtnApiSkuQuotaAdd.Size = new System.Drawing.Size(75, 23);
            this.BtnApiSkuQuotaAdd.TabIndex = 10;
            this.BtnApiSkuQuotaAdd.Text = "Add ▶";
            this.BtnApiSkuQuotaAdd.UseVisualStyleBackColor = true;
            // 
            // ECTextApiSkuQuotaData
            // 
            this.ECTextApiSkuQuotaData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextApiSkuQuotaData.BackColor = System.Drawing.SystemColors.Window;
            this.ECTextApiSkuQuotaData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.ECTextApiSkuQuotaData.Location = new System.Drawing.Point(264, 18);
            this.ECTextApiSkuQuotaData.Multiline = true;
            this.ECTextApiSkuQuotaData.Name = "ECTextApiSkuQuotaData";
            this.ECTextApiSkuQuotaData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextApiSkuQuotaData.Size = new System.Drawing.Size(474, 104);
            this.ECTextApiSkuQuotaData.TabIndex = 11;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.label9.Location = new System.Drawing.Point(34, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Code:";
            // 
            // ECTextApiSkuQuotaCode
            // 
            this.ECTextApiSkuQuotaCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.ECTextApiSkuQuotaCode.Location = new System.Drawing.Point(78, 19);
            this.ECTextApiSkuQuotaCode.Name = "ECTextApiSkuQuotaCode";
            this.ECTextApiSkuQuotaCode.Size = new System.Drawing.Size(168, 20);
            this.ECTextApiSkuQuotaCode.TabIndex = 7;
            // 
            // ECTextApiSkuQuotaQuota
            // 
            this.ECTextApiSkuQuotaQuota.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextApiSkuQuotaQuota.Location = new System.Drawing.Point(78, 71);
            this.ECTextApiSkuQuotaQuota.Name = "ECTextApiSkuQuotaQuota";
            this.ECTextApiSkuQuotaQuota.Size = new System.Drawing.Size(168, 20);
            this.ECTextApiSkuQuotaQuota.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.label10.Location = new System.Drawing.Point(31, 48);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Name:";
            // 
            // ECTextApiSkuQuotaName
            // 
            this.ECTextApiSkuQuotaName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.ECTextApiSkuQuotaName.Location = new System.Drawing.Point(78, 45);
            this.ECTextApiSkuQuotaName.Name = "ECTextApiSkuQuotaName";
            this.ECTextApiSkuQuotaName.Size = new System.Drawing.Size(168, 20);
            this.ECTextApiSkuQuotaName.TabIndex = 8;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.label11.Location = new System.Drawing.Point(30, 74);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(39, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Quota:";
            // 
            // ECCBApiIconData
            // 
            this.ECCBApiIconData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECCBApiIconData.BackColor = System.Drawing.SystemColors.Window;
            this.ECCBApiIconData.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ECCBApiIconData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.ECCBApiIconData.FormattingEnabled = true;
            this.ECCBApiIconData.Items.AddRange(new object[] {
            "ECCBApiIconData"});
            this.ECCBApiIconData.Location = new System.Drawing.Point(105, 58);
            this.ECCBApiIconData.Name = "ECCBApiIconData";
            this.ECCBApiIconData.Size = new System.Drawing.Size(645, 21);
            this.ECCBApiIconData.TabIndex = 24;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.label7.Location = new System.Drawing.Point(50, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "Api Icon:";
            // 
            // ECTextApiSubTitle
            // 
            this.ECTextApiSubTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextApiSubTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.ECTextApiSubTitle.Location = new System.Drawing.Point(105, 32);
            this.ECTextApiSubTitle.Name = "ECTextApiSubTitle";
            this.ECTextApiSubTitle.Size = new System.Drawing.Size(645, 20);
            this.ECTextApiSubTitle.TabIndex = 23;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.label6.Location = new System.Drawing.Point(36, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "Description:";
            // 
            // ECTextApiTitle
            // 
            this.ECTextApiTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextApiTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.ECTextApiTitle.Location = new System.Drawing.Point(473, 6);
            this.ECTextApiTitle.Name = "ECTextApiTitle";
            this.ECTextApiTitle.Size = new System.Drawing.Size(276, 20);
            this.ECTextApiTitle.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.label5.Location = new System.Drawing.Point(437, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 22;
            this.label5.Text = "Title:";
            // 
            // ECTextApiItem
            // 
            this.ECTextApiItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.ECTextApiItem.Location = new System.Drawing.Point(105, 6);
            this.ECTextApiItem.Name = "ECTextApiItem";
            this.ECTextApiItem.Size = new System.Drawing.Size(250, 20);
            this.ECTextApiItem.TabIndex = 20;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(10)));
            this.label3.Location = new System.Drawing.Point(22, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "ApiTypeName:";
            // 
            // TabQuickStarts
            // 
            this.TabQuickStarts.Controls.Add(this.ECBtnSaveQuickStartsInfo);
            this.TabQuickStarts.Controls.Add(this.ECBtnAddQuickStartItem);
            this.TabQuickStarts.Controls.Add(this.groupBox8);
            this.TabQuickStarts.Controls.Add(this.groupBox7);
            this.TabQuickStarts.Location = new System.Drawing.Point(4, 22);
            this.TabQuickStarts.Name = "TabQuickStarts";
            this.TabQuickStarts.Size = new System.Drawing.Size(756, 491);
            this.TabQuickStarts.TabIndex = 2;
            this.TabQuickStarts.Text = "QuickStarts";
            this.TabQuickStarts.UseVisualStyleBackColor = true;
            // 
            // ECBtnSaveQuickStartsInfo
            // 
            this.ECBtnSaveQuickStartsInfo.Location = new System.Drawing.Point(626, 465);
            this.ECBtnSaveQuickStartsInfo.Name = "ECBtnSaveQuickStartsInfo";
            this.ECBtnSaveQuickStartsInfo.Size = new System.Drawing.Size(125, 23);
            this.ECBtnSaveQuickStartsInfo.TabIndex = 15;
            this.ECBtnSaveQuickStartsInfo.Text = "Save QuickStarts";
            this.ECBtnSaveQuickStartsInfo.UseVisualStyleBackColor = true;
            // 
            // ECBtnAddQuickStartItem
            // 
            this.ECBtnAddQuickStartItem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ECBtnAddQuickStartItem.Location = new System.Drawing.Point(485, 221);
            this.ECBtnAddQuickStartItem.Name = "ECBtnAddQuickStartItem";
            this.ECBtnAddQuickStartItem.Size = new System.Drawing.Size(260, 23);
            this.ECBtnAddQuickStartItem.TabIndex = 8;
            this.ECBtnAddQuickStartItem.Text = "Add Quick Start Item ▼\r\n";
            this.ECBtnAddQuickStartItem.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox8.Controls.Add(this.ECCBQuickStartItemIcon);
            this.groupBox8.Controls.Add(this.groupBox9);
            this.groupBox8.Controls.Add(this.ECTextQuickStartItemDescription);
            this.groupBox8.Controls.Add(this.label13);
            this.groupBox8.Controls.Add(this.label12);
            this.groupBox8.Controls.Add(this.ECTextQuickStartItemTitle);
            this.groupBox8.Controls.Add(this.label4);
            this.groupBox8.Location = new System.Drawing.Point(3, 3);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(748, 212);
            this.groupBox8.TabIndex = 14;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Quick Start Item";
            // 
            // ECCBQuickStartItemIcon
            // 
            this.ECCBQuickStartItemIcon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECCBQuickStartItemIcon.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ECCBQuickStartItemIcon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECCBQuickStartItemIcon.FormattingEnabled = true;
            this.ECCBQuickStartItemIcon.Items.AddRange(new object[] {
            "BaseImages.Info",
            "BaseImages.Publish",
            "BaseImages.Tools"});
            this.ECCBQuickStartItemIcon.Location = new System.Drawing.Point(390, 18);
            this.ECCBQuickStartItemIcon.Name = "ECCBQuickStartItemIcon";
            this.ECCBQuickStartItemIcon.Size = new System.Drawing.Size(352, 21);
            this.ECCBQuickStartItemIcon.TabIndex = 7;
            // 
            // groupBox9
            // 
            this.groupBox9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox9.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox9.Controls.Add(this.ECBtnAddLinkItem);
            this.groupBox9.Controls.Add(this.ECTextQuickStartItemLinks);
            this.groupBox9.Controls.Add(this.ECTextQuickStartItemLinkUri);
            this.groupBox9.Controls.Add(this.label15);
            this.groupBox9.Controls.Add(this.ECTextQuickStartItemLinkTitle);
            this.groupBox9.Controls.Add(this.label14);
            this.groupBox9.Location = new System.Drawing.Point(6, 71);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(736, 136);
            this.groupBox9.TabIndex = 6;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Links";
            // 
            // ECBtnAddLinkItem
            // 
            this.ECBtnAddLinkItem.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.ECBtnAddLinkItem.Location = new System.Drawing.Point(246, 107);
            this.ECBtnAddLinkItem.Name = "ECBtnAddLinkItem";
            this.ECBtnAddLinkItem.Size = new System.Drawing.Size(85, 23);
            this.ECBtnAddLinkItem.TabIndex = 5;
            this.ECBtnAddLinkItem.Text = "Add Link ▶";
            this.ECBtnAddLinkItem.UseVisualStyleBackColor = true;
            // 
            // ECTextQuickStartItemLinks
            // 
            this.ECTextQuickStartItemLinks.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextQuickStartItemLinks.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextQuickStartItemLinks.Location = new System.Drawing.Point(337, 19);
            this.ECTextQuickStartItemLinks.Multiline = true;
            this.ECTextQuickStartItemLinks.Name = "ECTextQuickStartItemLinks";
            this.ECTextQuickStartItemLinks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextQuickStartItemLinks.Size = new System.Drawing.Size(393, 111);
            this.ECTextQuickStartItemLinks.TabIndex = 4;
            // 
            // ECTextQuickStartItemLinkUri
            // 
            this.ECTextQuickStartItemLinkUri.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextQuickStartItemLinkUri.Location = new System.Drawing.Point(47, 52);
            this.ECTextQuickStartItemLinkUri.Multiline = true;
            this.ECTextQuickStartItemLinkUri.Name = "ECTextQuickStartItemLinkUri";
            this.ECTextQuickStartItemLinkUri.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextQuickStartItemLinkUri.Size = new System.Drawing.Size(284, 49);
            this.ECTextQuickStartItemLinkUri.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(18, 52);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(23, 13);
            this.label15.TabIndex = 2;
            this.label15.Text = "Uri:";
            // 
            // ECTextQuickStartItemLinkTitle
            // 
            this.ECTextQuickStartItemLinkTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextQuickStartItemLinkTitle.Location = new System.Drawing.Point(47, 23);
            this.ECTextQuickStartItemLinkTitle.Name = "ECTextQuickStartItemLinkTitle";
            this.ECTextQuickStartItemLinkTitle.Size = new System.Drawing.Size(284, 20);
            this.ECTextQuickStartItemLinkTitle.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(10, 26);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "Text:";
            // 
            // ECTextQuickStartItemDescription
            // 
            this.ECTextQuickStartItemDescription.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextQuickStartItemDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextQuickStartItemDescription.Location = new System.Drawing.Point(85, 45);
            this.ECTextQuickStartItemDescription.Name = "ECTextQuickStartItemDescription";
            this.ECTextQuickStartItemDescription.Size = new System.Drawing.Size(657, 20);
            this.ECTextQuickStartItemDescription.TabIndex = 5;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(16, 48);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 13);
            this.label13.TabIndex = 4;
            this.label13.Text = "Description:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(353, 21);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 13);
            this.label12.TabIndex = 2;
            this.label12.Text = "Icon:";
            // 
            // ECTextQuickStartItemTitle
            // 
            this.ECTextQuickStartItemTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextQuickStartItemTitle.Location = new System.Drawing.Point(85, 19);
            this.ECTextQuickStartItemTitle.Name = "ECTextQuickStartItemTitle";
            this.ECTextQuickStartItemTitle.Size = new System.Drawing.Size(252, 20);
            this.ECTextQuickStartItemTitle.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(49, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Title:";
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox7.BackColor = System.Drawing.Color.Transparent;
            this.groupBox7.Controls.Add(this.ECTextQuickStartItems);
            this.groupBox7.Location = new System.Drawing.Point(3, 250);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(748, 209);
            this.groupBox7.TabIndex = 13;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Quick Start Items";
            // 
            // ECTextQuickStartItems
            // 
            this.ECTextQuickStartItems.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextQuickStartItems.BackColor = System.Drawing.SystemColors.Window;
            this.ECTextQuickStartItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextQuickStartItems.Location = new System.Drawing.Point(6, 19);
            this.ECTextQuickStartItems.Multiline = true;
            this.ECTextQuickStartItems.Name = "ECTextQuickStartItems";
            this.ECTextQuickStartItems.ReadOnly = true;
            this.ECTextQuickStartItems.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextQuickStartItems.Size = new System.Drawing.Size(736, 184);
            this.ECTextQuickStartItems.TabIndex = 9;
            // 
            // TabSpec
            // 
            this.TabSpec.Controls.Add(this.ECBtnSaveSpecInfo);
            this.TabSpec.Controls.Add(this.tabControl5);
            this.TabSpec.Location = new System.Drawing.Point(4, 22);
            this.TabSpec.Name = "TabSpec";
            this.TabSpec.Size = new System.Drawing.Size(756, 491);
            this.TabSpec.TabIndex = 3;
            this.TabSpec.Text = "Spec";
            this.TabSpec.UseVisualStyleBackColor = true;
            // 
            // ECBtnSaveSpecInfo
            // 
            this.ECBtnSaveSpecInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ECBtnSaveSpecInfo.Location = new System.Drawing.Point(626, 465);
            this.ECBtnSaveSpecInfo.Name = "ECBtnSaveSpecInfo";
            this.ECBtnSaveSpecInfo.Size = new System.Drawing.Size(125, 23);
            this.ECBtnSaveSpecInfo.TabIndex = 1;
            this.ECBtnSaveSpecInfo.Text = "Save Spec";
            this.ECBtnSaveSpecInfo.UseVisualStyleBackColor = true;
            // 
            // tabControl5
            // 
            this.tabControl5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl5.Controls.Add(this.TabSpecFeatures);
            this.tabControl5.Controls.Add(this.TabSpecItems);
            this.tabControl5.Controls.Add(this.TabSpecCostItems);
            this.tabControl5.Controls.Add(this.TabAllowZeroCost);
            this.tabControl5.Location = new System.Drawing.Point(3, 3);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(750, 456);
            this.tabControl5.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl5.TabIndex = 0;
            // 
            // TabSpecFeatures
            // 
            this.TabSpecFeatures.Controls.Add(this.ECBtnAddSpecFeatureItem);
            this.TabSpecFeatures.Controls.Add(this.groupBox11);
            this.TabSpecFeatures.Controls.Add(this.groupBox10);
            this.TabSpecFeatures.Location = new System.Drawing.Point(4, 22);
            this.TabSpecFeatures.Name = "TabSpecFeatures";
            this.TabSpecFeatures.Padding = new System.Windows.Forms.Padding(3);
            this.TabSpecFeatures.Size = new System.Drawing.Size(742, 430);
            this.TabSpecFeatures.TabIndex = 0;
            this.TabSpecFeatures.Text = "Features";
            this.TabSpecFeatures.UseVisualStyleBackColor = true;
            // 
            // ECBtnAddSpecFeatureItem
            // 
            this.ECBtnAddSpecFeatureItem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ECBtnAddSpecFeatureItem.Location = new System.Drawing.Point(470, 122);
            this.ECBtnAddSpecFeatureItem.Name = "ECBtnAddSpecFeatureItem";
            this.ECBtnAddSpecFeatureItem.Size = new System.Drawing.Size(260, 23);
            this.ECBtnAddSpecFeatureItem.TabIndex = 7;
            this.ECBtnAddSpecFeatureItem.Text = "Add Feature Item ▼";
            this.ECBtnAddSpecFeatureItem.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox11.Controls.Add(this.ECTextSpecFeatureItems);
            this.groupBox11.Location = new System.Drawing.Point(6, 151);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(730, 273);
            this.groupBox11.TabIndex = 1;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Feature Items";
            // 
            // ECTextSpecFeatureItems
            // 
            this.ECTextSpecFeatureItems.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextSpecFeatureItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecFeatureItems.Location = new System.Drawing.Point(6, 19);
            this.ECTextSpecFeatureItems.Multiline = true;
            this.ECTextSpecFeatureItems.Name = "ECTextSpecFeatureItems";
            this.ECTextSpecFeatureItems.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextSpecFeatureItems.Size = new System.Drawing.Size(718, 248);
            this.ECTextSpecFeatureItems.TabIndex = 0;
            // 
            // groupBox10
            // 
            this.groupBox10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox10.Controls.Add(this.ECCBSpecFeatureItemIconSvgData);
            this.groupBox10.Controls.Add(this.ECTextSpecFeatureItemIconName);
            this.groupBox10.Controls.Add(this.label18);
            this.groupBox10.Controls.Add(this.label17);
            this.groupBox10.Controls.Add(this.ECTextSpecFeatureItemDisplayName);
            this.groupBox10.Controls.Add(this.label16);
            this.groupBox10.Location = new System.Drawing.Point(6, 6);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(730, 110);
            this.groupBox10.TabIndex = 0;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Feature Item";
            // 
            // ECCBSpecFeatureItemIconSvgData
            // 
            this.ECCBSpecFeatureItemIconSvgData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECCBSpecFeatureItemIconSvgData.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ECCBSpecFeatureItemIconSvgData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECCBSpecFeatureItemIconSvgData.FormattingEnabled = true;
            this.ECCBSpecFeatureItemIconSvgData.Location = new System.Drawing.Point(97, 55);
            this.ECCBSpecFeatureItemIconSvgData.Name = "ECCBSpecFeatureItemIconSvgData";
            this.ECCBSpecFeatureItemIconSvgData.Size = new System.Drawing.Size(627, 21);
            this.ECCBSpecFeatureItemIconSvgData.TabIndex = 6;
            // 
            // ECTextSpecFeatureItemIconName
            // 
            this.ECTextSpecFeatureItemIconName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextSpecFeatureItemIconName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecFeatureItemIconName.Location = new System.Drawing.Point(97, 82);
            this.ECTextSpecFeatureItemIconName.Name = "ECTextSpecFeatureItemIconName";
            this.ECTextSpecFeatureItemIconName.Size = new System.Drawing.Size(627, 20);
            this.ECTextSpecFeatureItemIconName.TabIndex = 5;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(29, 85);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(62, 13);
            this.label18.TabIndex = 4;
            this.label18.Text = "Icon Name:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(21, 58);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 13);
            this.label17.TabIndex = 3;
            this.label17.Text = "Feature Icon:";
            // 
            // ECTextSpecFeatureItemDisplayName
            // 
            this.ECTextSpecFeatureItemDisplayName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextSpecFeatureItemDisplayName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecFeatureItemDisplayName.Location = new System.Drawing.Point(97, 29);
            this.ECTextSpecFeatureItemDisplayName.Name = "ECTextSpecFeatureItemDisplayName";
            this.ECTextSpecFeatureItemDisplayName.Size = new System.Drawing.Size(627, 20);
            this.ECTextSpecFeatureItemDisplayName.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(16, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(75, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Display Name:";
            // 
            // TabSpecItems
            // 
            this.TabSpecItems.Controls.Add(this.groupBox15);
            this.TabSpecItems.Controls.Add(this.button6);
            this.TabSpecItems.Controls.Add(this.groupBox12);
            this.TabSpecItems.Location = new System.Drawing.Point(4, 22);
            this.TabSpecItems.Name = "TabSpecItems";
            this.TabSpecItems.Padding = new System.Windows.Forms.Padding(3);
            this.TabSpecItems.Size = new System.Drawing.Size(742, 430);
            this.TabSpecItems.TabIndex = 1;
            this.TabSpecItems.Text = "Specs";
            this.TabSpecItems.UseVisualStyleBackColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox15.Controls.Add(this.ECTextSpecItems);
            this.groupBox15.Location = new System.Drawing.Point(12, 310);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(724, 114);
            this.groupBox15.TabIndex = 2;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Spec Items";
            // 
            // ECTextSpecItems
            // 
            this.ECTextSpecItems.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextSpecItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecItems.Location = new System.Drawing.Point(6, 19);
            this.ECTextSpecItems.Multiline = true;
            this.ECTextSpecItems.Name = "ECTextSpecItems";
            this.ECTextSpecItems.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextSpecItems.Size = new System.Drawing.Size(712, 89);
            this.ECTextSpecItems.TabIndex = 0;
            // 
            // button6
            // 
            this.button6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button6.Location = new System.Drawing.Point(470, 281);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(260, 23);
            this.button6.TabIndex = 1;
            this.button6.Text = "Add Spec Item ▼";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox12.Controls.Add(this.ECCBSpecItemColorScheme);
            this.groupBox12.Controls.Add(this.groupBox16);
            this.groupBox12.Controls.Add(this.groupBox14);
            this.groupBox12.Controls.Add(this.groupBox13);
            this.groupBox12.Controls.Add(this.ECTextSpecItemTitle);
            this.groupBox12.Controls.Add(this.label21);
            this.groupBox12.Controls.Add(this.label20);
            this.groupBox12.Controls.Add(this.ECTextSpecItemSpecCode);
            this.groupBox12.Controls.Add(this.label19);
            this.groupBox12.Location = new System.Drawing.Point(6, 6);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(730, 269);
            this.groupBox12.TabIndex = 0;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Spec Item";
            // 
            // ECCBSpecItemColorScheme
            // 
            this.ECCBSpecItemColorScheme.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ECCBSpecItemColorScheme.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ECCBSpecItemColorScheme.FormattingEnabled = true;
            this.ECCBSpecItemColorScheme.Location = new System.Drawing.Point(533, 19);
            this.ECCBSpecItemColorScheme.Name = "ECCBSpecItemColorScheme";
            this.ECCBSpecItemColorScheme.Size = new System.Drawing.Size(191, 21);
            this.ECCBSpecItemColorScheme.TabIndex = 9;
            // 
            // groupBox16
            // 
            this.groupBox16.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox16.Controls.Add(this.ECTextSpecItemCostCaption);
            this.groupBox16.Controls.Add(this.label27);
            this.groupBox16.Controls.Add(this.label26);
            this.groupBox16.Controls.Add(this.ECTextSpecItemCostCurrencyCode);
            this.groupBox16.Controls.Add(this.ECTextSpecItemCostAmount);
            this.groupBox16.Controls.Add(this.label25);
            this.groupBox16.Location = new System.Drawing.Point(6, 214);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(718, 50);
            this.groupBox16.TabIndex = 8;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Cost";
            // 
            // ECTextSpecItemCostCaption
            // 
            this.ECTextSpecItemCostCaption.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextSpecItemCostCaption.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecItemCostCaption.Location = new System.Drawing.Point(434, 24);
            this.ECTextSpecItemCostCaption.Name = "ECTextSpecItemCostCaption";
            this.ECTextSpecItemCostCaption.Size = new System.Drawing.Size(278, 20);
            this.ECTextSpecItemCostCaption.TabIndex = 5;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(382, 26);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(46, 13);
            this.label27.TabIndex = 4;
            this.label27.Text = "Caption:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(168, 27);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(77, 13);
            this.label26.TabIndex = 3;
            this.label26.Text = "CurrencyCode:";
            // 
            // ECTextSpecItemCostCurrencyCode
            // 
            this.ECTextSpecItemCostCurrencyCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecItemCostCurrencyCode.Location = new System.Drawing.Point(251, 23);
            this.ECTextSpecItemCostCurrencyCode.Name = "ECTextSpecItemCostCurrencyCode";
            this.ECTextSpecItemCostCurrencyCode.Size = new System.Drawing.Size(100, 20);
            this.ECTextSpecItemCostCurrencyCode.TabIndex = 2;
            // 
            // ECTextSpecItemCostAmount
            // 
            this.ECTextSpecItemCostAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecItemCostAmount.Location = new System.Drawing.Point(51, 24);
            this.ECTextSpecItemCostAmount.Name = "ECTextSpecItemCostAmount";
            this.ECTextSpecItemCostAmount.Size = new System.Drawing.Size(100, 20);
            this.ECTextSpecItemCostAmount.TabIndex = 1;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(6, 26);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(46, 13);
            this.label25.TabIndex = 0;
            this.label25.Text = "Amount:";
            // 
            // groupBox14
            // 
            this.groupBox14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox14.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox14.Controls.Add(this.ECTextSpecItemFeatureIDs);
            this.groupBox14.Controls.Add(this.ECBtnAddFeatureID);
            this.groupBox14.Controls.Add(this.ECCBSpecItemFeatureID);
            this.groupBox14.Controls.Add(this.label24);
            this.groupBox14.Location = new System.Drawing.Point(360, 71);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(364, 137);
            this.groupBox14.TabIndex = 7;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Features";
            // 
            // ECTextSpecItemFeatureIDs
            // 
            this.ECTextSpecItemFeatureIDs.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextSpecItemFeatureIDs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecItemFeatureIDs.Location = new System.Drawing.Point(132, 19);
            this.ECTextSpecItemFeatureIDs.Multiline = true;
            this.ECTextSpecItemFeatureIDs.Name = "ECTextSpecItemFeatureIDs";
            this.ECTextSpecItemFeatureIDs.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextSpecItemFeatureIDs.Size = new System.Drawing.Size(226, 111);
            this.ECTextSpecItemFeatureIDs.TabIndex = 3;
            // 
            // ECBtnAddFeatureID
            // 
            this.ECBtnAddFeatureID.Location = new System.Drawing.Point(51, 107);
            this.ECBtnAddFeatureID.Name = "ECBtnAddFeatureID";
            this.ECBtnAddFeatureID.Size = new System.Drawing.Size(75, 23);
            this.ECBtnAddFeatureID.TabIndex = 2;
            this.ECBtnAddFeatureID.Text = "Add ▶";
            this.ECBtnAddFeatureID.UseVisualStyleBackColor = true;
            // 
            // ECCBSpecItemFeatureID
            // 
            this.ECCBSpecItemFeatureID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ECCBSpecItemFeatureID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECCBSpecItemFeatureID.FormattingEnabled = true;
            this.ECCBSpecItemFeatureID.Location = new System.Drawing.Point(6, 81);
            this.ECCBSpecItemFeatureID.Name = "ECCBSpecItemFeatureID";
            this.ECCBSpecItemFeatureID.Size = new System.Drawing.Size(120, 21);
            this.ECCBSpecItemFeatureID.TabIndex = 1;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(6, 65);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(57, 13);
            this.label24.TabIndex = 0;
            this.label24.Text = "FeatureID:";
            // 
            // groupBox13
            // 
            this.groupBox13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox13.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox13.Controls.Add(this.ECBtnAddPromotedFeature);
            this.groupBox13.Controls.Add(this.ECTextSpecItemPromotedFeatureItemUnitDescription);
            this.groupBox13.Controls.Add(this.ECTextSpecItemPromotedFeatureItemValue);
            this.groupBox13.Controls.Add(this.label23);
            this.groupBox13.Controls.Add(this.ECTextSpecItemPromotedFeatureItems);
            this.groupBox13.Controls.Add(this.label22);
            this.groupBox13.Location = new System.Drawing.Point(6, 71);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(348, 137);
            this.groupBox13.TabIndex = 6;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "PromotedFeatures";
            // 
            // ECBtnAddPromotedFeature
            // 
            this.ECBtnAddPromotedFeature.Location = new System.Drawing.Point(51, 107);
            this.ECBtnAddPromotedFeature.Name = "ECBtnAddPromotedFeature";
            this.ECBtnAddPromotedFeature.Size = new System.Drawing.Size(75, 23);
            this.ECBtnAddPromotedFeature.TabIndex = 5;
            this.ECBtnAddPromotedFeature.Text = "Add ▶";
            this.ECBtnAddPromotedFeature.UseVisualStyleBackColor = true;
            // 
            // ECTextSpecItemPromotedFeatureItemUnitDescription
            // 
            this.ECTextSpecItemPromotedFeatureItemUnitDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecItemPromotedFeatureItemUnitDescription.Location = new System.Drawing.Point(6, 81);
            this.ECTextSpecItemPromotedFeatureItemUnitDescription.Name = "ECTextSpecItemPromotedFeatureItemUnitDescription";
            this.ECTextSpecItemPromotedFeatureItemUnitDescription.Size = new System.Drawing.Size(120, 20);
            this.ECTextSpecItemPromotedFeatureItemUnitDescription.TabIndex = 4;
            // 
            // ECTextSpecItemPromotedFeatureItemValue
            // 
            this.ECTextSpecItemPromotedFeatureItemValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecItemPromotedFeatureItemValue.Location = new System.Drawing.Point(6, 42);
            this.ECTextSpecItemPromotedFeatureItemValue.Name = "ECTextSpecItemPromotedFeatureItemValue";
            this.ECTextSpecItemPromotedFeatureItemValue.Size = new System.Drawing.Size(120, 20);
            this.ECTextSpecItemPromotedFeatureItemValue.TabIndex = 3;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 26);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(37, 13);
            this.label23.TabIndex = 2;
            this.label23.Text = "Value:";
            // 
            // ECTextSpecItemPromotedFeatureItems
            // 
            this.ECTextSpecItemPromotedFeatureItems.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextSpecItemPromotedFeatureItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecItemPromotedFeatureItems.Location = new System.Drawing.Point(132, 19);
            this.ECTextSpecItemPromotedFeatureItems.Multiline = true;
            this.ECTextSpecItemPromotedFeatureItems.Name = "ECTextSpecItemPromotedFeatureItems";
            this.ECTextSpecItemPromotedFeatureItems.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextSpecItemPromotedFeatureItems.Size = new System.Drawing.Size(210, 111);
            this.ECTextSpecItemPromotedFeatureItems.TabIndex = 1;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(6, 65);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(82, 13);
            this.label22.TabIndex = 0;
            this.label22.Text = "UnitDescription:";
            // 
            // ECTextSpecItemTitle
            // 
            this.ECTextSpecItemTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextSpecItemTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecItemTitle.Location = new System.Drawing.Point(83, 45);
            this.ECTextSpecItemTitle.Name = "ECTextSpecItemTitle";
            this.ECTextSpecItemTitle.Size = new System.Drawing.Size(641, 20);
            this.ECTextSpecItemTitle.TabIndex = 5;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(47, 52);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(30, 13);
            this.label21.TabIndex = 4;
            this.label21.Text = "Title:";
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(454, 22);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(73, 13);
            this.label20.TabIndex = 2;
            this.label20.Text = "ColorScheme:";
            // 
            // ECTextSpecItemSpecCode
            // 
            this.ECTextSpecItemSpecCode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextSpecItemSpecCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecItemSpecCode.Location = new System.Drawing.Point(83, 19);
            this.ECTextSpecItemSpecCode.Name = "ECTextSpecItemSpecCode";
            this.ECTextSpecItemSpecCode.Size = new System.Drawing.Size(351, 20);
            this.ECTextSpecItemSpecCode.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(17, 22);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(60, 13);
            this.label19.TabIndex = 0;
            this.label19.Text = "SpecCode:";
            // 
            // TabSpecCostItems
            // 
            this.TabSpecCostItems.Controls.Add(this.groupBox19);
            this.TabSpecCostItems.Controls.Add(this.ECBtnAddSpecDefaultItem);
            this.TabSpecCostItems.Controls.Add(this.groupBox17);
            this.TabSpecCostItems.Location = new System.Drawing.Point(4, 22);
            this.TabSpecCostItems.Name = "TabSpecCostItems";
            this.TabSpecCostItems.Size = new System.Drawing.Size(742, 430);
            this.TabSpecCostItems.TabIndex = 2;
            this.TabSpecCostItems.Text = "Cost Item";
            this.TabSpecCostItems.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox19.Controls.Add(this.ECTextSpecDefaultItems);
            this.groupBox19.Location = new System.Drawing.Point(3, 280);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(736, 147);
            this.groupBox19.TabIndex = 2;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Default Items";
            // 
            // ECTextSpecDefaultItems
            // 
            this.ECTextSpecDefaultItems.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextSpecDefaultItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecDefaultItems.Location = new System.Drawing.Point(0, 19);
            this.ECTextSpecDefaultItems.Multiline = true;
            this.ECTextSpecDefaultItems.Name = "ECTextSpecDefaultItems";
            this.ECTextSpecDefaultItems.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextSpecDefaultItems.Size = new System.Drawing.Size(730, 122);
            this.ECTextSpecDefaultItems.TabIndex = 0;
            // 
            // ECBtnAddSpecDefaultItem
            // 
            this.ECBtnAddSpecDefaultItem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ECBtnAddSpecDefaultItem.Location = new System.Drawing.Point(473, 251);
            this.ECBtnAddSpecDefaultItem.Name = "ECBtnAddSpecDefaultItem";
            this.ECBtnAddSpecDefaultItem.Size = new System.Drawing.Size(260, 23);
            this.ECBtnAddSpecDefaultItem.TabIndex = 1;
            this.ECBtnAddSpecDefaultItem.Text = "Add Default Item▼";
            this.ECBtnAddSpecDefaultItem.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox17.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox17.Controls.Add(this.groupBox18);
            this.groupBox17.Controls.Add(this.ECCBSpecDefaultItemSpecCode);
            this.groupBox17.Controls.Add(this.label29);
            this.groupBox17.Location = new System.Drawing.Point(3, 3);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(736, 242);
            this.groupBox17.TabIndex = 0;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Default Item";
            // 
            // groupBox18
            // 
            this.groupBox18.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox18.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox18.Controls.Add(this.ECBtnAddSpecDefaultItemFirstPartyItem);
            this.groupBox18.Controls.Add(this.ECTextSpecDefaultItemFirstPartyItems);
            this.groupBox18.Controls.Add(this.ECTextSpecDefaultItemFirstPartyQuantity);
            this.groupBox18.Controls.Add(this.label31);
            this.groupBox18.Controls.Add(this.ECTextSpecDefaultItemFirstPartyResourceID);
            this.groupBox18.Controls.Add(this.label30);
            this.groupBox18.Location = new System.Drawing.Point(6, 55);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(724, 181);
            this.groupBox18.TabIndex = 2;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "FirstParty";
            // 
            // ECBtnAddSpecDefaultItemFirstPartyItem
            // 
            this.ECBtnAddSpecDefaultItemFirstPartyItem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ECBtnAddSpecDefaultItemFirstPartyItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECBtnAddSpecDefaultItemFirstPartyItem.Location = new System.Drawing.Point(315, 48);
            this.ECBtnAddSpecDefaultItemFirstPartyItem.Name = "ECBtnAddSpecDefaultItemFirstPartyItem";
            this.ECBtnAddSpecDefaultItemFirstPartyItem.Size = new System.Drawing.Size(158, 23);
            this.ECBtnAddSpecDefaultItemFirstPartyItem.TabIndex = 5;
            this.ECBtnAddSpecDefaultItemFirstPartyItem.Text = "Add First Party Item▼";
            this.ECBtnAddSpecDefaultItemFirstPartyItem.UseVisualStyleBackColor = true;
            // 
            // ECTextSpecDefaultItemFirstPartyItems
            // 
            this.ECTextSpecDefaultItemFirstPartyItems.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextSpecDefaultItemFirstPartyItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecDefaultItemFirstPartyItems.Location = new System.Drawing.Point(6, 76);
            this.ECTextSpecDefaultItemFirstPartyItems.Multiline = true;
            this.ECTextSpecDefaultItemFirstPartyItems.Name = "ECTextSpecDefaultItemFirstPartyItems";
            this.ECTextSpecDefaultItemFirstPartyItems.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextSpecDefaultItemFirstPartyItems.Size = new System.Drawing.Size(712, 99);
            this.ECTextSpecDefaultItemFirstPartyItems.TabIndex = 4;
            // 
            // ECTextSpecDefaultItemFirstPartyQuantity
            // 
            this.ECTextSpecDefaultItemFirstPartyQuantity.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextSpecDefaultItemFirstPartyQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecDefaultItemFirstPartyQuantity.Location = new System.Drawing.Point(79, 50);
            this.ECTextSpecDefaultItemFirstPartyQuantity.Name = "ECTextSpecDefaultItemFirstPartyQuantity";
            this.ECTextSpecDefaultItemFirstPartyQuantity.Size = new System.Drawing.Size(230, 20);
            this.ECTextSpecDefaultItemFirstPartyQuantity.TabIndex = 3;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(24, 53);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(49, 13);
            this.label31.TabIndex = 2;
            this.label31.Text = "Quantity:";
            // 
            // ECTextSpecDefaultItemFirstPartyResourceID
            // 
            this.ECTextSpecDefaultItemFirstPartyResourceID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextSpecDefaultItemFirstPartyResourceID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecDefaultItemFirstPartyResourceID.Location = new System.Drawing.Point(79, 24);
            this.ECTextSpecDefaultItemFirstPartyResourceID.Name = "ECTextSpecDefaultItemFirstPartyResourceID";
            this.ECTextSpecDefaultItemFirstPartyResourceID.Size = new System.Drawing.Size(639, 20);
            this.ECTextSpecDefaultItemFirstPartyResourceID.TabIndex = 1;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(6, 27);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(67, 13);
            this.label30.TabIndex = 0;
            this.label30.Text = "ResourceID:";
            // 
            // ECCBSpecDefaultItemSpecCode
            // 
            this.ECCBSpecDefaultItemSpecCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ECCBSpecDefaultItemSpecCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECCBSpecDefaultItemSpecCode.FormattingEnabled = true;
            this.ECCBSpecDefaultItemSpecCode.Location = new System.Drawing.Point(85, 24);
            this.ECCBSpecDefaultItemSpecCode.Name = "ECCBSpecDefaultItemSpecCode";
            this.ECCBSpecDefaultItemSpecCode.Size = new System.Drawing.Size(211, 21);
            this.ECCBSpecDefaultItemSpecCode.TabIndex = 1;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(19, 27);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(60, 13);
            this.label29.TabIndex = 0;
            this.label29.Text = "SpecCode:";
            // 
            // TabAllowZeroCost
            // 
            this.TabAllowZeroCost.Controls.Add(this.ECTextSpecAllowZeroCostSpecCodeItems);
            this.TabAllowZeroCost.Controls.Add(this.ECBtnAddSpecAllowZeroCostSpecCodeItem);
            this.TabAllowZeroCost.Controls.Add(this.ECCBSpecAllowZeroCostSpecCode);
            this.TabAllowZeroCost.Controls.Add(this.label28);
            this.TabAllowZeroCost.Location = new System.Drawing.Point(4, 22);
            this.TabAllowZeroCost.Name = "TabAllowZeroCost";
            this.TabAllowZeroCost.Size = new System.Drawing.Size(742, 430);
            this.TabAllowZeroCost.TabIndex = 3;
            this.TabAllowZeroCost.Text = "AllowZeroCost";
            this.TabAllowZeroCost.UseVisualStyleBackColor = true;
            // 
            // ECTextSpecAllowZeroCostSpecCodeItems
            // 
            this.ECTextSpecAllowZeroCostSpecCodeItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextSpecAllowZeroCostSpecCodeItems.Location = new System.Drawing.Point(76, 61);
            this.ECTextSpecAllowZeroCostSpecCodeItems.Multiline = true;
            this.ECTextSpecAllowZeroCostSpecCodeItems.Name = "ECTextSpecAllowZeroCostSpecCodeItems";
            this.ECTextSpecAllowZeroCostSpecCodeItems.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextSpecAllowZeroCostSpecCodeItems.Size = new System.Drawing.Size(211, 266);
            this.ECTextSpecAllowZeroCostSpecCodeItems.TabIndex = 3;
            // 
            // ECBtnAddSpecAllowZeroCostSpecCodeItem
            // 
            this.ECBtnAddSpecAllowZeroCostSpecCodeItem.Location = new System.Drawing.Point(212, 32);
            this.ECBtnAddSpecAllowZeroCostSpecCodeItem.Name = "ECBtnAddSpecAllowZeroCostSpecCodeItem";
            this.ECBtnAddSpecAllowZeroCostSpecCodeItem.Size = new System.Drawing.Size(75, 23);
            this.ECBtnAddSpecAllowZeroCostSpecCodeItem.TabIndex = 2;
            this.ECBtnAddSpecAllowZeroCostSpecCodeItem.Text = "Add ▼";
            this.ECBtnAddSpecAllowZeroCostSpecCodeItem.UseVisualStyleBackColor = true;
            // 
            // ECCBSpecAllowZeroCostSpecCode
            // 
            this.ECCBSpecAllowZeroCostSpecCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ECCBSpecAllowZeroCostSpecCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECCBSpecAllowZeroCostSpecCode.FormattingEnabled = true;
            this.ECCBSpecAllowZeroCostSpecCode.Items.AddRange(new object[] {
            "ECCBSpecAllowZeroCostSpecCode"});
            this.ECCBSpecAllowZeroCostSpecCode.Location = new System.Drawing.Point(76, 5);
            this.ECCBSpecAllowZeroCostSpecCode.Name = "ECCBSpecAllowZeroCostSpecCode";
            this.ECCBSpecAllowZeroCostSpecCode.Size = new System.Drawing.Size(211, 21);
            this.ECCBSpecAllowZeroCostSpecCode.TabIndex = 1;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(10, 8);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(60, 13);
            this.label28.TabIndex = 0;
            this.label28.Text = "SpecCode:";
            // 
            // TabOverAll
            // 
            this.TabOverAll.Controls.Add(this.ECRDBSaveAsFolder);
            this.TabOverAll.Controls.Add(this.ECRDBSaveAsZip);
            this.TabOverAll.Controls.Add(this.ECBtnUploadToPPEBlob);
            this.TabOverAll.Controls.Add(this.groupBox26);
            this.TabOverAll.Controls.Add(this.groupBox23);
            this.TabOverAll.Controls.Add(this.groupBox22);
            this.TabOverAll.Controls.Add(this.groupBox21);
            this.TabOverAll.Controls.Add(this.groupBox20);
            this.TabOverAll.Controls.Add(this.ECBtnSaveToLocal);
            this.TabOverAll.Location = new System.Drawing.Point(4, 22);
            this.TabOverAll.Name = "TabOverAll";
            this.TabOverAll.Size = new System.Drawing.Size(756, 491);
            this.TabOverAll.TabIndex = 4;
            this.TabOverAll.Text = "OverAll";
            this.TabOverAll.UseVisualStyleBackColor = true;
            // 
            // ECRDBSaveAsFolder
            // 
            this.ECRDBSaveAsFolder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ECRDBSaveAsFolder.AutoSize = true;
            this.ECRDBSaveAsFolder.Location = new System.Drawing.Point(83, 468);
            this.ECRDBSaveAsFolder.Name = "ECRDBSaveAsFolder";
            this.ECRDBSaveAsFolder.Size = new System.Drawing.Size(60, 17);
            this.ECRDBSaveAsFolder.TabIndex = 15;
            this.ECRDBSaveAsFolder.Text = "Folder";
            this.ECRDBSaveAsFolder.UseVisualStyleBackColor = true;
            // 
            // ECRDBSaveAsZip
            // 
            this.ECRDBSaveAsZip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ECRDBSaveAsZip.AutoSize = true;
            this.ECRDBSaveAsZip.Checked = true;
            this.ECRDBSaveAsZip.Location = new System.Drawing.Point(22, 468);
            this.ECRDBSaveAsZip.Name = "ECRDBSaveAsZip";
            this.ECRDBSaveAsZip.Size = new System.Drawing.Size(43, 17);
            this.ECRDBSaveAsZip.TabIndex = 14;
            this.ECRDBSaveAsZip.TabStop = true;
            this.ECRDBSaveAsZip.Text = "Zip";
            this.ECRDBSaveAsZip.UseVisualStyleBackColor = true;
            // 
            // ECBtnUploadToPPEBlob
            // 
            this.ECBtnUploadToPPEBlob.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ECBtnUploadToPPEBlob.Location = new System.Drawing.Point(593, 465);
            this.ECBtnUploadToPPEBlob.Name = "ECBtnUploadToPPEBlob";
            this.ECBtnUploadToPPEBlob.Size = new System.Drawing.Size(160, 23);
            this.ECBtnUploadToPPEBlob.TabIndex = 7;
            this.ECBtnUploadToPPEBlob.Text = "Upload To PPE Blob";
            this.ECBtnUploadToPPEBlob.UseVisualStyleBackColor = true;
            // 
            // groupBox26
            // 
            this.groupBox26.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox26.Controls.Add(this.ECTextOverAllSvgIcons);
            this.groupBox26.Location = new System.Drawing.Point(521, 237);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(232, 222);
            this.groupBox26.TabIndex = 13;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Svg Icons";
            // 
            // ECTextOverAllSvgIcons
            // 
            this.ECTextOverAllSvgIcons.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextOverAllSvgIcons.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextOverAllSvgIcons.Location = new System.Drawing.Point(6, 19);
            this.ECTextOverAllSvgIcons.Multiline = true;
            this.ECTextOverAllSvgIcons.Name = "ECTextOverAllSvgIcons";
            this.ECTextOverAllSvgIcons.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextOverAllSvgIcons.Size = new System.Drawing.Size(220, 197);
            this.ECTextOverAllSvgIcons.TabIndex = 0;
            // 
            // groupBox23
            // 
            this.groupBox23.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox23.Controls.Add(this.ECTextOverAllResourceENJson);
            this.groupBox23.Location = new System.Drawing.Point(3, 237);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(512, 222);
            this.groupBox23.TabIndex = 12;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Resource(EN)";
            // 
            // ECTextOverAllResourceENJson
            // 
            this.ECTextOverAllResourceENJson.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextOverAllResourceENJson.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextOverAllResourceENJson.Location = new System.Drawing.Point(6, 19);
            this.ECTextOverAllResourceENJson.Multiline = true;
            this.ECTextOverAllResourceENJson.Name = "ECTextOverAllResourceENJson";
            this.ECTextOverAllResourceENJson.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextOverAllResourceENJson.Size = new System.Drawing.Size(500, 197);
            this.ECTextOverAllResourceENJson.TabIndex = 0;
            // 
            // groupBox22
            // 
            this.groupBox22.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox22.Controls.Add(this.ECTextOverAllSpecJson);
            this.groupBox22.Location = new System.Drawing.Point(521, 3);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(232, 228);
            this.groupBox22.TabIndex = 11;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Spec.Json Content";
            // 
            // ECTextOverAllSpecJson
            // 
            this.ECTextOverAllSpecJson.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextOverAllSpecJson.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextOverAllSpecJson.Location = new System.Drawing.Point(6, 19);
            this.ECTextOverAllSpecJson.Multiline = true;
            this.ECTextOverAllSpecJson.Name = "ECTextOverAllSpecJson";
            this.ECTextOverAllSpecJson.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextOverAllSpecJson.Size = new System.Drawing.Size(220, 203);
            this.ECTextOverAllSpecJson.TabIndex = 0;
            // 
            // groupBox21
            // 
            this.groupBox21.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox21.Controls.Add(this.ECTextOverAllQuickStartsJson);
            this.groupBox21.Location = new System.Drawing.Point(249, 3);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(266, 228);
            this.groupBox21.TabIndex = 10;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "QuickStarts.Json Content";
            // 
            // ECTextOverAllQuickStartsJson
            // 
            this.ECTextOverAllQuickStartsJson.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextOverAllQuickStartsJson.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextOverAllQuickStartsJson.Location = new System.Drawing.Point(6, 19);
            this.ECTextOverAllQuickStartsJson.Multiline = true;
            this.ECTextOverAllQuickStartsJson.Name = "ECTextOverAllQuickStartsJson";
            this.ECTextOverAllQuickStartsJson.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextOverAllQuickStartsJson.Size = new System.Drawing.Size(254, 203);
            this.ECTextOverAllQuickStartsJson.TabIndex = 0;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.ECTextOverAllApiJson);
            this.groupBox20.Location = new System.Drawing.Point(3, 3);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(240, 228);
            this.groupBox20.TabIndex = 9;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Api.Json Content";
            // 
            // ECTextOverAllApiJson
            // 
            this.ECTextOverAllApiJson.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextOverAllApiJson.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextOverAllApiJson.Location = new System.Drawing.Point(6, 19);
            this.ECTextOverAllApiJson.Multiline = true;
            this.ECTextOverAllApiJson.Name = "ECTextOverAllApiJson";
            this.ECTextOverAllApiJson.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ECTextOverAllApiJson.Size = new System.Drawing.Size(228, 203);
            this.ECTextOverAllApiJson.TabIndex = 0;
            // 
            // ECBtnSaveToLocal
            // 
            this.ECBtnSaveToLocal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ECBtnSaveToLocal.Location = new System.Drawing.Point(160, 465);
            this.ECBtnSaveToLocal.Name = "ECBtnSaveToLocal";
            this.ECBtnSaveToLocal.Size = new System.Drawing.Size(137, 23);
            this.ECBtnSaveToLocal.TabIndex = 8;
            this.ECBtnSaveToLocal.Text = "Save To Local";
            this.ECBtnSaveToLocal.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.ECTextActionMessage);
            this.groupBox2.Controls.Add(this.ECListItems);
            this.groupBox2.Controls.Add(this.ECBtnLoadFromLocal);
            this.groupBox2.Controls.Add(this.ECBtnLoadFromPPEBlob);
            this.groupBox2.Controls.Add(this.ECBtnCreate);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(164, 582);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Action and Review";
            // 
            // ECTextActionMessage
            // 
            this.ECTextActionMessage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ECTextActionMessage.AutoSize = true;
            this.ECTextActionMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ECTextActionMessage.ForeColor = System.Drawing.Color.Red;
            this.ECTextActionMessage.Location = new System.Drawing.Point(6, 544);
            this.ECTextActionMessage.Name = "ECTextActionMessage";
            this.ECTextActionMessage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ECTextActionMessage.Size = new System.Drawing.Size(146, 13);
            this.ECTextActionMessage.TabIndex = 5;
            this.ECTextActionMessage.Text = "Message1111111111111111";
            // 
            // ECListItems
            // 
            this.ECListItems.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.ECListItems.FormattingEnabled = true;
            this.ECListItems.HorizontalScrollbar = true;
            this.ECListItems.Location = new System.Drawing.Point(9, 105);
            this.ECListItems.Name = "ECListItems";
            this.ECListItems.Size = new System.Drawing.Size(149, 424);
            this.ECListItems.TabIndex = 4;
            this.ECListItems.DoubleClick += new System.EventHandler(this.ECListItems_DoubleClick);
            // 
            // ECBtnLoadFromLocal
            // 
            this.ECBtnLoadFromLocal.Location = new System.Drawing.Point(9, 48);
            this.ECBtnLoadFromLocal.Name = "ECBtnLoadFromLocal";
            this.ECBtnLoadFromLocal.Size = new System.Drawing.Size(149, 23);
            this.ECBtnLoadFromLocal.TabIndex = 3;
            this.ECBtnLoadFromLocal.Text = "Load From Local";
            this.ECBtnLoadFromLocal.UseVisualStyleBackColor = true;
            this.ECBtnLoadFromLocal.Click += new System.EventHandler(this.ECBtnLoadFromLocal_Click);
            // 
            // ECBtnLoadFromPPEBlob
            // 
            this.ECBtnLoadFromPPEBlob.Location = new System.Drawing.Point(9, 77);
            this.ECBtnLoadFromPPEBlob.Name = "ECBtnLoadFromPPEBlob";
            this.ECBtnLoadFromPPEBlob.Size = new System.Drawing.Size(149, 23);
            this.ECBtnLoadFromPPEBlob.TabIndex = 2;
            this.ECBtnLoadFromPPEBlob.Text = "Load From PPE Blob";
            this.ECBtnLoadFromPPEBlob.UseVisualStyleBackColor = true;
            this.ECBtnLoadFromPPEBlob.Click += new System.EventHandler(this.ECBtnLoadFromPPEBlob_Click);
            // 
            // ECBtnCreate
            // 
            this.ECBtnCreate.Location = new System.Drawing.Point(9, 19);
            this.ECBtnCreate.Name = "ECBtnCreate";
            this.ECBtnCreate.Size = new System.Drawing.Size(149, 23);
            this.ECBtnCreate.TabIndex = 1;
            this.ECBtnCreate.Text = "Create";
            this.ECBtnCreate.UseVisualStyleBackColor = true;
            this.ECBtnCreate.Click += new System.EventHandler(this.ECBtnCreate_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.ECTextStorageAccountKey);
            this.groupBox1.Controls.Add(this.ECBtnUploadToProBlob);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.ECTextStorageAccount);
            this.groupBox1.Location = new System.Drawing.Point(6, 592);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(940, 77);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Upload To Production";
            // 
            // ECTextStorageAccountKey
            // 
            this.ECTextStorageAccountKey.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextStorageAccountKey.Location = new System.Drawing.Point(117, 45);
            this.ECTextStorageAccountKey.Name = "ECTextStorageAccountKey";
            this.ECTextStorageAccountKey.Size = new System.Drawing.Size(817, 20);
            this.ECTextStorageAccountKey.TabIndex = 4;
            // 
            // ECBtnUploadToProBlob
            // 
            this.ECBtnUploadToProBlob.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ECBtnUploadToProBlob.Location = new System.Drawing.Point(746, 17);
            this.ECBtnUploadToProBlob.Name = "ECBtnUploadToProBlob";
            this.ECBtnUploadToProBlob.Size = new System.Drawing.Size(188, 23);
            this.ECBtnUploadToProBlob.TabIndex = 2;
            this.ECBtnUploadToProBlob.Text = "Upload To Production Blob";
            this.ECBtnUploadToProBlob.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "StorageAccountKey:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "StorageAccount:";
            // 
            // ECTextStorageAccount
            // 
            this.ECTextStorageAccount.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ECTextStorageAccount.Location = new System.Drawing.Point(117, 19);
            this.ECTextStorageAccount.Name = "ECTextStorageAccount";
            this.ECTextStorageAccount.Size = new System.Drawing.Size(623, 20);
            this.ECTextStorageAccount.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tabControl2);
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(952, 675);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Sku Configuration";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(946, 669);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(938, 643);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "PPE";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(938, 643);
            this.tabPage5.TabIndex = 1;
            this.tabPage5.Text = "Production";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tabControl3);
            this.tabPage3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(952, 675);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Meter Configuration";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl3.Controls.Add(this.tabPage6);
            this.tabControl3.Controls.Add(this.tabPage7);
            this.tabControl3.Location = new System.Drawing.Point(3, 3);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(946, 669);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(938, 643);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "PPE";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tabPage7
            // 
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(938, 643);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "Production";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMinSize = new System.Drawing.Size(971, 727);
            this.ClientSize = new System.Drawing.Size(984, 727);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "MainForm";
            this.Text = "ApiOnboadingConfigurationTool";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.groupBox27.ResumeLayout(false);
            this.TabApiItemPage.ResumeLayout(false);
            this.TabIcon.ResumeLayout(false);
            this.TabIcon.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.TabApi.ResumeLayout(false);
            this.TabApi.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.TabQuickStarts.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.TabSpec.ResumeLayout(false);
            this.tabControl5.ResumeLayout(false);
            this.TabSpecFeatures.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.TabSpecItems.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.TabSpecCostItems.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.TabAllowZeroCost.ResumeLayout(false);
            this.TabAllowZeroCost.PerformLayout();
            this.TabOverAll.ResumeLayout(false);
            this.TabOverAll.PerformLayout();
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button ECBtnLoadFromLocal;
        private System.Windows.Forms.Button ECBtnLoadFromPPEBlob;
        private System.Windows.Forms.Button ECBtnCreate;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox ECTextStorageAccountKey;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button ECBtnUploadToProBlob;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ECTextStorageAccount;
        private System.Windows.Forms.CheckedListBox ECListItems;
        private System.Windows.Forms.Label ECTextActionMessage;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabControl TabApiItemPage;
        private System.Windows.Forms.TabPage TabIcon;
        private System.Windows.Forms.Label ECLabelIconFolderPath;
        private System.Windows.Forms.TextBox ECTextIconFolderPath;
        private System.Windows.Forms.Button ECBtnSelectSvgFolder;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox ECTextSvgFiles;
        private System.Windows.Forms.TabPage TabQuickStarts;
        private System.Windows.Forms.Button ECBtnSaveQuickStartsInfo;
        private System.Windows.Forms.Button ECBtnAddQuickStartItem;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox ECCBQuickStartItemIcon;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button ECBtnAddLinkItem;
        private System.Windows.Forms.TextBox ECTextQuickStartItemLinks;
        private System.Windows.Forms.TextBox ECTextQuickStartItemLinkUri;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox ECTextQuickStartItemLinkTitle;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox ECTextQuickStartItemDescription;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox ECTextQuickStartItemTitle;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage TabSpec;
        private System.Windows.Forms.Button ECBtnSaveSpecInfo;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage TabSpecFeatures;
        private System.Windows.Forms.Button ECBtnAddSpecFeatureItem;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox ECTextSpecFeatureItems;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.ComboBox ECCBSpecFeatureItemIconSvgData;
        private System.Windows.Forms.TextBox ECTextSpecFeatureItemIconName;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox ECTextSpecFeatureItemDisplayName;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TabPage TabSpecItems;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.TextBox ECTextSpecItems;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.TextBox ECTextSpecItemCostCaption;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox ECTextSpecItemCostCurrencyCode;
        private System.Windows.Forms.TextBox ECTextSpecItemCostAmount;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TextBox ECTextSpecItemFeatureIDs;
        private System.Windows.Forms.Button ECBtnAddFeatureID;
        private System.Windows.Forms.ComboBox ECCBSpecItemFeatureID;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Button ECBtnAddPromotedFeature;
        private System.Windows.Forms.TextBox ECTextSpecItemPromotedFeatureItemUnitDescription;
        private System.Windows.Forms.TextBox ECTextSpecItemPromotedFeatureItemValue;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox ECTextSpecItemPromotedFeatureItems;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox ECTextSpecItemTitle;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox ECTextSpecItemSpecCode;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TabPage TabSpecCostItems;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.TextBox ECTextSpecDefaultItems;
        private System.Windows.Forms.Button ECBtnAddSpecDefaultItem;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Button ECBtnAddSpecDefaultItemFirstPartyItem;
        private System.Windows.Forms.TextBox ECTextSpecDefaultItemFirstPartyItems;
        private System.Windows.Forms.TextBox ECTextSpecDefaultItemFirstPartyQuantity;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox ECTextSpecDefaultItemFirstPartyResourceID;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox ECCBSpecDefaultItemSpecCode;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TabPage TabAllowZeroCost;
        private System.Windows.Forms.TextBox ECTextSpecAllowZeroCostSpecCodeItems;
        private System.Windows.Forms.Button ECBtnAddSpecAllowZeroCostSpecCodeItem;
        private System.Windows.Forms.ComboBox ECCBSpecAllowZeroCostSpecCode;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TabPage TabOverAll;
        private System.Windows.Forms.Button ECBtnSaveToLocal;
        private System.Windows.Forms.Button ECBtnUploadToPPEBlob;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox ECTextQuickStartItems;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.Button ECBtnSpecFlag;
        private System.Windows.Forms.Button ECBtnQuickStartsFlag;
        private System.Windows.Forms.Button ECBtnApiFlag;
        private System.Windows.Forms.Button ECBtnIconsFlag;
        private System.Windows.Forms.TabPage TabApi;
        private System.Windows.Forms.Button ECBtnSaveApiInfo;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox ECTextApiDefaultLegalTerm;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton ECRDBApiShowLegalTermTrue;
        private System.Windows.Forms.RadioButton ECRDBApiShowLegalTermFalse;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.Button BtnApiCategoryAdd;
        private System.Windows.Forms.TextBox ECTextApiCategory;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox ECTextApiCategories;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button BtnApiSkuQuotaAdd;
        private System.Windows.Forms.TextBox ECTextApiSkuQuotaData;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox ECTextApiSkuQuotaCode;
        private System.Windows.Forms.TextBox ECTextApiSkuQuotaQuota;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox ECTextApiSkuQuotaName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox ECCBApiIconData;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox ECTextApiSubTitle;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ECTextApiTitle;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox ECTextApiItem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton ECRDBSaveAsZip;
        private System.Windows.Forms.RadioButton ECRDBSaveAsFolder;
        private System.Windows.Forms.TextBox ECTextOverAllSvgIcons;
        private System.Windows.Forms.TextBox ECTextOverAllResourceENJson;
        private System.Windows.Forms.TextBox ECTextOverAllSpecJson;
        private System.Windows.Forms.TextBox ECTextOverAllQuickStartsJson;
        private System.Windows.Forms.TextBox ECTextOverAllApiJson;
        private System.Windows.Forms.ComboBox ECCBSpecItemColorScheme;
        private System.Windows.Forms.FolderBrowserDialog ECFolderBrowserDialog;
    }
}

